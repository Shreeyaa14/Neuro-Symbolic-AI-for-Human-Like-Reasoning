"""
Example Usage Script
Demonstrates various features of the Neuro-Symbolic Reasoning System
"""

from neuro_symbolic_system import NeuroSymbolicSystem
from dataset_generator import VisualDatasetGenerator, TextDatasetGenerator
import config
from pathlib import Path


def example_1_visual_reasoning():
    """
    Example 1: Visual Reasoning with Generated Image
    """
    print("\n" + "="*70)
    print("EXAMPLE 1: Visual Reasoning")
    print("="*70 + "\n")
    
    # Initialize system
    system = NeuroSymbolicSystem()
    
    # Generate a sample image
    gen = VisualDatasetGenerator()
    image, objects = gen.generate_image(num_objects=3)
    
    # Save image
    image_path = config.DATA_DIR / "example_image.png"
    image_path.parent.mkdir(exist_ok=True, parents=True)
    image.save(image_path)
    
    print("Generated image with objects:")
    for obj in objects:
        print(f"  - {obj['color']} {obj['shape']} ({obj['size']})")
    print()
    
    # Ask questions
    queries = [
        f"Is there a {objects[0]['color']} {objects[0]['shape']}?",
        "How many objects are in the image?",
        f"Is the {objects[0]['color']} {objects[0]['shape']} larger than the {objects[1]['color']} {objects[1]['shape']}?"
    ]
    
    for query in queries:
        print(f"\nQuery: {query}")
        result = system.process_visual_query(
            str(image_path),
            query,
            visualize=False
        )
        print(f"Answer: {result['reasoning']['answer']}")
        print(f"Confidence: Based on {len(result['detected_objects'])} detected objects")


def example_2_text_reasoning():
    """
    Example 2: Text-Based Logical Reasoning
    """
    print("\n" + "="*70)
    print("EXAMPLE 2: Text Reasoning")
    print("="*70 + "\n")
    
    # Initialize system
    system = NeuroSymbolicSystem()
    
    # Define reasoning problems
    problems = [
        {
            "name": "Syllogism",
            "text": "All mammals are animals. All dogs are mammals.",
            "query": "Is dog an animal?"
        },
        {
            "name": "Transitive Relation",
            "text": "Alice is taller than Bob. Bob is taller than Charlie.",
            "query": "Is Alice taller than Charlie?"
        },
        {
            "name": "Negation",
            "text": "No fish can fly.",
            "query": "Can fish fly?"
        }
    ]
    
    for problem in problems:
        print(f"\n{problem['name']}:")
        print(f"Premises: {problem['text']}")
        print(f"Query: {problem['query']}")
        
        result = system.process_text_query(
            problem['text'],
            problem['query']
        )
        
        print(f"Answer: {result['reasoning']['answer']}")
        print(f"Inference Time: {result['metrics']['inference_time']:.3f}s")


def example_3_batch_processing():
    """
    Example 3: Batch Processing Multiple Queries
    """
    print("\n" + "="*70)
    print("EXAMPLE 3: Batch Processing")
    print("="*70 + "\n")
    
    system = NeuroSymbolicSystem()
    
    # Generate dataset
    gen = TextDatasetGenerator()
    dataset = gen.generate_dataset(num_examples=5)
    
    test_cases = []
    for item in dataset[:5]:
        test_cases.append({
            "type": "text",
            "text": item["text"],
            "query": item["query"],
            "expected_answer": item["answer"]
        })
    
    # Batch evaluate
    results = system.batch_evaluate(test_cases)
    
    print(f"Processed {results['total_cases']} test cases")
    print(f"Accuracy: {results['accuracy']:.2%}")
    print(f"Average Time: {results['average_time']:.3f}s")
    
    # Show some results
    print("\nSample Results:")
    for i, result in enumerate(results['results'][:3]):
        tc = result['test_case']
        print(f"\n  Test {i+1}: {tc['query']}")
        print(f"  Expected: {tc['expected_answer']}")
        print(f"  Got: {result['result']['reasoning']['answer']}")
        print(f"  {'✓ CORRECT' if result['correct'] else '✗ INCORRECT'}")


def example_4_explanation_analysis():
    """
    Example 4: Analyzing Reasoning Explanations
    """
    print("\n" + "="*70)
    print("EXAMPLE 4: Explanation Analysis")
    print("="*70 + "\n")
    
    system = NeuroSymbolicSystem()
    
    # Complex query requiring multi-step reasoning
    text = """
    All mammals are warm-blooded.
    All warm-blooded animals regulate temperature.
    Dogs are mammals.
    """
    
    query = "Do dogs regulate temperature?"
    
    print(f"Premises:\n{text}")
    print(f"Query: {query}\n")
    
    result = system.process_text_query(text, query)
    
    print("Full Reasoning Trace:")
    print(result['reasoning']['explanation'])
    print("\nKnowledge Base:")
    print(result['reasoning']['knowledge_base'])
    print(f"\nFinal Answer: {result['reasoning']['answer']}")


def example_5_custom_rules():
    """
    Example 5: Adding Custom Domain Rules
    """
    print("\n" + "="*70)
    print("EXAMPLE 5: Custom Domain Rules")
    print("="*70 + "\n")
    
    from symbolic_module import SymbolicReasoningModule
    
    # Create symbolic reasoner
    symbolic = SymbolicReasoningModule()
    
    # Add custom domain knowledge about animals
    symbolic.kb.add_fact("mammal", "dog")
    symbolic.kb.add_fact("mammal", "cat")
    symbolic.kb.add_fact("mammal", "whale")
    symbolic.kb.add_fact("bird", "eagle")
    symbolic.kb.add_fact("bird", "penguin")
    
    # Add custom rules
    symbolic.kb.add_rule(
        "can_fly", ("X",),
        [("bird", ("X",))]
    )
    
    # But penguins can't fly - add exception
    symbolic.kb.add_fact("cannot_fly", "penguin")
    
    # Query
    queries = [
        ("can_fly", "eagle"),
        ("can_fly", "penguin"),
        ("mammal", "dog")
    ]
    
    print("Custom Domain: Animal Kingdom\n")
    for pred, arg in queries:
        result = symbolic.engine.query(pred, arg)
        answer = "YES" if result else "NO"
        print(f"Query: {pred}({arg})?")
        print(f"Answer: {answer}\n")


def example_6_visual_analysis():
    """
    Example 6: Detailed Visual Analysis
    """
    print("\n" + "="*70)
    print("EXAMPLE 6: Detailed Visual Analysis")
    print("="*70 + "\n")
    
    system = NeuroSymbolicSystem()
    gen = VisualDatasetGenerator()
    
    # Generate image
    image, objects = gen.generate_image(num_objects=5)
    image_path = config.DATA_DIR / "detailed_example.png"
    image.save(image_path)
    
    print(f"Generated image with {len(objects)} objects\n")
    
    # Run multiple analyses
    analyses = [
        ("Object Detection", "What objects are in the image?"),
        ("Color Analysis", f"Are there any {objects[0]['color']} objects?"),
        ("Shape Counting", f"How many {objects[0]['shape']}s are there?"),
        ("Size Comparison", "Which object is the largest?"),
    ]
    
    for analysis_name, query in analyses:
        print(f"{analysis_name}: {query}")
        result = system.process_visual_query(
            str(image_path),
            query,
            visualize=False
        )
        
        print(f"  Objects detected: {len(result['detected_objects'])}")
        print(f"  Answer: {result['reasoning']['answer']}")
        print()


def main():
    """
    Run all examples
    """
    print("""
    ╔══════════════════════════════════════════════════════════════════╗
    ║                                                                  ║
    ║             NEURO-SYMBOLIC REASONING EXAMPLES                   ║
    ║                                                                  ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)
    
    examples = [
        ("Visual Reasoning", example_1_visual_reasoning),
        ("Text Reasoning", example_2_text_reasoning),
        ("Batch Processing", example_3_batch_processing),
        ("Explanation Analysis", example_4_explanation_analysis),
        ("Custom Rules", example_5_custom_rules),
        ("Visual Analysis", example_6_visual_analysis),
    ]
    
    print("\nAvailable Examples:")
    for i, (name, _) in enumerate(examples, 1):
        print(f"  {i}. {name}")
    
    print("\nRunning all examples...\n")
    
    for name, example_func in examples:
        try:
            example_func()
        except Exception as e:
            print(f"Error in {name}: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*70)
    print("All examples completed!")
    print("="*70)


if __name__ == "__main__":
    main()
