"""
Dataset Generator for Neuro-Symbolic Reasoning
Creates synthetic visual and text reasoning datasets
"""

import numpy as np
from PIL import Image, ImageDraw
import random
import json
from pathlib import Path
from typing import List, Dict, Tuple
from loguru import logger

import config


class VisualDatasetGenerator:
    """
    Generate synthetic images with geometric shapes for visual reasoning
    """
    def __init__(self, image_size: int = 400):
        self.image_size = image_size
        self.shapes = config.OBJECT_CLASSES["shapes"][:4]  # circle, square, triangle, rectangle
        self.colors = config.OBJECT_CLASSES["colors"][:6]
        self.sizes = {
            "small": (30, 50),
            "medium": (60, 90),
            "large": (100, 130)
        }
        
    def generate_dataset(self, num_images: int = 100, output_dir: Path = None):
        """
        Generate a complete dataset with images and annotations
        """
        if output_dir is None:
            output_dir = config.DATA_DIR / "custom_visual"
        
        output_dir.mkdir(exist_ok=True, parents=True)
        images_dir = output_dir / "images"
        images_dir.mkdir(exist_ok=True)
        
        dataset = []
        
        for i in range(num_images):
            # Generate image with random objects
            image, objects = self.generate_image(num_objects=random.randint(2, 6))
            
            # Save image
            image_path = images_dir / f"image_{i:04d}.png"
            image.save(image_path)
            
            # Generate questions
            questions = self.generate_questions(objects)
            
            dataset.append({
                "image_id": i,
                "image_path": str(image_path),
                "objects": objects,
                "questions": questions
            })
        
        # Save dataset metadata
        with open(output_dir / "dataset.json", 'w') as f:
            json.dump(dataset, f, indent=2)
        
        logger.success(f"Generated {num_images} images in {output_dir}")
        return dataset
    
    def generate_image(self, num_objects: int = 4) -> Tuple[Image.Image, List[Dict]]:
        """
        Generate a single image with multiple objects
        """
        # Create blank image
        image = Image.new('RGB', (self.image_size, self.image_size), 'white')
        draw = ImageDraw.Draw(image)
        
        objects = []
        occupied_regions = []
        
        for i in range(num_objects):
            # Random attributes
            shape = random.choice(self.shapes)
            color = random.choice(self.colors)
            size_category = random.choice(list(self.sizes.keys()))
            size_range = self.sizes[size_category]
            size = random.randint(*size_range)
            
            # Find non-overlapping position
            max_attempts = 50
            for _ in range(max_attempts):
                x = random.randint(size, self.image_size - size)
                y = random.randint(size, self.image_size - size)
                
                # Check overlap
                overlaps = False
                for (ox, oy, osize) in occupied_regions:
                    distance = np.sqrt((x - ox)**2 + (y - oy)**2)
                    if distance < (size + osize) * 0.7:
                        overlaps = True
                        break
                
                if not overlaps:
                    break
            
            # Draw shape
            self._draw_shape(draw, shape, x, y, size, color)
            
            occupied_regions.append((x, y, size))
            
            # Store object info
            objects.append({
                "id": f"obj_{i+1}",
                "shape": shape,
                "color": color,
                "size": size_category,
                "position": {"x": x, "y": y},
                "bbox": (x - size//2, y - size//2, size, size)
            })
        
        return image, objects
    
    def _draw_shape(self, draw: ImageDraw, shape: str, x: int, y: int, 
                   size: int, color: str):
        """Draw a shape on the image"""
        half_size = size // 2
        
        # Color mapping
        color_map = {
            "red": "#FF0000",
            "blue": "#0000FF",
            "green": "#00FF00",
            "yellow": "#FFFF00",
            "purple": "#800080",
            "orange": "#FFA500",
            "cyan": "#00FFFF",
            "magenta": "#FF00FF"
        }
        fill_color = color_map.get(color, "#000000")
        
        if shape == "circle":
            draw.ellipse(
                [x - half_size, y - half_size, x + half_size, y + half_size],
                fill=fill_color,
                outline="black",
                width=2
            )
        elif shape == "square":
            draw.rectangle(
                [x - half_size, y - half_size, x + half_size, y + half_size],
                fill=fill_color,
                outline="black",
                width=2
            )
        elif shape == "triangle":
            points = [
                (x, y - half_size),
                (x - half_size, y + half_size),
                (x + half_size, y + half_size)
            ]
            draw.polygon(points, fill=fill_color, outline="black")
        elif shape == "rectangle":
            draw.rectangle(
                [x - half_size, y - half_size//2, x + half_size, y + half_size//2],
                fill=fill_color,
                outline="black",
                width=2
            )
    
    def generate_questions(self, objects: List[Dict]) -> List[Dict]:
        """
        Generate reasoning questions about the objects
        """
        questions = []
        
        # Existence questions
        for obj in objects[:2]:
            questions.append({
                "question": f"Is there a {obj['color']} {obj['shape']}?",
                "answer": "TRUE",
                "type": "existence"
            })
        
        # Non-existence
        non_existent_color = random.choice([c for c in self.colors 
                                           if c not in [o['color'] for o in objects]])
        questions.append({
            "question": f"Is there a {non_existent_color} circle?",
            "answer": "FALSE",
            "type": "existence"
        })
        
        # Counting
        if len(objects) >= 2:
            shape_counts = {}
            for obj in objects:
                shape_counts[obj['shape']] = shape_counts.get(obj['shape'], 0) + 1
            
            for shape, count in shape_counts.items():
                questions.append({
                    "question": f"How many {shape}s are there?",
                    "answer": str(count),
                    "type": "counting"
                })
        
        # Comparison
        if len(objects) >= 2:
            obj1, obj2 = objects[0], objects[1]
            size_order = ["small", "medium", "large"]
            
            if size_order.index(obj1['size']) > size_order.index(obj2['size']):
                questions.append({
                    "question": f"Is the {obj1['color']} {obj1['shape']} larger than the {obj2['color']} {obj2['shape']}?",
                    "answer": "TRUE",
                    "type": "comparison"
                })
        
        return questions


class TextDatasetGenerator:
    """
    Generate text-based logical reasoning problems
    """
    def __init__(self):
        self.categories = ["animals", "people", "objects"]
        
    def generate_dataset(self, num_examples: int = 100, output_dir: Path = None):
        """
        Generate text reasoning dataset
        """
        if output_dir is None:
            output_dir = config.DATA_DIR / "text_reasoning"
        
        output_dir.mkdir(exist_ok=True, parents=True)
        
        dataset = []
        
        for i in range(num_examples):
            example = self.generate_example()
            dataset.append({
                "id": i,
                **example
            })
        
        # Save dataset
        with open(output_dir / "dataset.json", 'w') as f:
            json.dump(dataset, f, indent=2)
        
        logger.success(f"Generated {num_examples} text examples in {output_dir}")
        return dataset
    
    def generate_example(self) -> Dict:
        """
        Generate a single logical reasoning example
        """
        reasoning_type = random.choice(["syllogism", "transitive", "negation"])
        
        if reasoning_type == "syllogism":
            return self._generate_syllogism()
        elif reasoning_type == "transitive":
            return self._generate_transitive()
        else:
            return self._generate_negation()
    
    def _generate_syllogism(self) -> Dict:
        """
        Generate a syllogistic reasoning problem
        All A are B. All B are C. Therefore, all A are C.
        """
        # Example taxonomy
        taxonomies = [
            ("dogs", "mammals", "animals"),
            ("roses", "flowers", "plants"),
            ("squares", "rectangles", "shapes"),
            ("trucks", "vehicles", "machines")
        ]
        
        a, b, c = random.choice(taxonomies)
        
        premises = [
            f"All {a} are {b}.",
            f"All {b} are {c}."
        ]
        
        query = f"Is {a[:-1]} {c[:-1]}?"  # singular form
        
        return {
            "type": "syllogism",
            "premises": premises,
            "text": " ".join(premises),
            "query": query,
            "answer": "TRUE"
        }
    
    def _generate_transitive(self) -> Dict:
        """
        Generate a transitive relation problem
        A > B, B > C => A > C
        """
        names = ["Alice", "Bob", "Charlie", "David", "Emma"]
        selected = random.sample(names, 3)
        
        relation = random.choice(["taller than", "older than", "faster than"])
        
        premises = [
            f"{selected[0]} is {relation} {selected[1]}.",
            f"{selected[1]} is {relation} {selected[2]}."
        ]
        
        query = f"Is {selected[0]} {relation} {selected[2]}?"
        
        return {
            "type": "transitive",
            "premises": premises,
            "text": " ".join(premises),
            "query": query,
            "answer": "TRUE"
        }
    
    def _generate_negation(self) -> Dict:
        """
        Generate a negation reasoning problem
        """
        subjects = ["cats", "birds", "fish", "reptiles"]
        properties = ["fly", "swim", "run", "climb"]
        
        subject = random.choice(subjects)
        prop = random.choice(properties)
        
        # Create contradictory statement
        premises = [f"No {subject} can {prop}."]
        query = f"Can {subject[:-1]} {prop}?"  # singular
        
        return {
            "type": "negation",
            "premises": premises,
            "text": " ".join(premises),
            "query": query,
            "answer": "FALSE"
        }


def generate_all_datasets():
    """
    Generate all datasets for the project
    """
    logger.info("Generating datasets...")
    
    # Visual dataset
    visual_gen = VisualDatasetGenerator()
    visual_dataset = visual_gen.generate_dataset(num_images=50)
    
    # Text dataset
    text_gen = TextDatasetGenerator()
    text_dataset = text_gen.generate_dataset(num_examples=50)
    
    logger.success("All datasets generated successfully!")
    
    return {
        "visual": visual_dataset,
        "text": text_dataset
    }


if __name__ == "__main__":
    datasets = generate_all_datasets()
    logger.info(f"Generated {len(datasets['visual'])} visual examples")
    logger.info(f"Generated {len(datasets['text'])} text examples")
