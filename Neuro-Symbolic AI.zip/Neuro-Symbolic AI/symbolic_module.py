"""
Symbolic Reasoning Module (System 2)
Implements deliberate, logical reasoning using symbolic inference
"""

from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass
from collections import defaultdict
import re
from loguru import logger


@dataclass
class Fact:
    """Represents a logical fact"""
    predicate: str
    arguments: Tuple[str, ...]
    
    def __str__(self):
        args_str = ", ".join(self.arguments)
        return f"{self.predicate}({args_str})"
    
    def __hash__(self):
        return hash((self.predicate, self.arguments))


@dataclass
class Rule:
    """Represents a logical rule (Horn clause)"""
    head: Fact
    body: List[Fact]
    
    def __str__(self):
        body_str = ", ".join(str(f) for f in self.body)
        return f"{self.head} :- {body_str}" if self.body else str(self.head)


class KnowledgeBase:
    """
    Storage and management of logical facts and rules
    """
    def __init__(self):
        self.facts: Set[Fact] = set()
        self.rules: List[Rule] = []
        self.fact_index: Dict[str, List[Fact]] = defaultdict(list)
        
    def add_fact(self, predicate: str, *arguments: str):
        """Add a fact to the knowledge base"""
        fact = Fact(predicate, tuple(str(arg) for arg in arguments))
        self.facts.add(fact)
        self.fact_index[predicate].append(fact)
        logger.debug(f"Added fact: {fact}")
    
    def add_rule(self, head_predicate: str, head_args: Tuple[str, ...], 
                 body: List[Tuple[str, Tuple[str, ...]]]):
        """Add a rule to the knowledge base"""
        head = Fact(head_predicate, head_args)
        body_facts = [Fact(pred, args) for pred, args in body]
        rule = Rule(head, body_facts)
        self.rules.append(rule)
        logger.debug(f"Added rule: {rule}")
    
    def clear(self):
        """Clear all facts and rules"""
        self.facts.clear()
        self.rules.clear()
        self.fact_index.clear()

    def clear_facts(self):
        """Clear facts while keeping rules intact"""
        self.facts.clear()
        self.fact_index.clear()
    
    def get_facts_by_predicate(self, predicate: str) -> List[Fact]:
        """Retrieve all facts with given predicate"""
        return self.fact_index.get(predicate, [])
    
    def to_prolog_format(self) -> str:
        """Convert knowledge base to Prolog format"""
        lines = []
        
        # Facts
        for fact in sorted(self.facts, key=str):
            args = ", ".join(fact.arguments)
            lines.append(f"{fact.predicate}({args}).")
        
        # Rules
        for rule in self.rules:
            lines.append(str(rule) + ".")
        
        return "\n".join(lines)


class UnificationEngine:
    """
    Unification algorithm for pattern matching
    """
    @staticmethod
    def unify(term1: Any, term2: Any, substitution: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """
        Unify two terms and return substitution if successful
        """
        if substitution is None:
            substitution = {}
        
        # If terms are equal
        if term1 == term2:
            return substitution
        
        # If term1 is a variable
        if isinstance(term1, str) and term1.isupper():
            return UnificationEngine._unify_var(term1, term2, substitution)
        
        # If term2 is a variable
        if isinstance(term2, str) and term2.isupper():
            return UnificationEngine._unify_var(term2, term1, substitution)
        
        # If both are tuples/lists
        if isinstance(term1, (tuple, list)) and isinstance(term2, (tuple, list)):
            if len(term1) != len(term2):
                return None

            for t1, t2 in zip(term1, term2):
                substitution = UnificationEngine.unify(t1, t2, substitution)
                if substitution is None:
                    return None
            return substitution
        
        return None
    
    @staticmethod
    def _unify_var(var: str, term: Any, substitution: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Unify a variable with a term"""
        if var in substitution:
            return UnificationEngine.unify(substitution[var], term, substitution)
        elif isinstance(term, str) and term.isupper() and term in substitution:
            return UnificationEngine.unify(var, substitution[term], substitution)
        else:
            new_sub = substitution.copy()
            new_sub[var] = term
            return new_sub
    
    @staticmethod
    def apply_substitution(term: Any, substitution: Dict[str, Any]) -> Any:
        """Apply substitution to a term"""
        if isinstance(term, str) and term in substitution:
            return UnificationEngine.apply_substitution(substitution[term], substitution)
        elif isinstance(term, (tuple, list)):
            return type(term)(UnificationEngine.apply_substitution(t, substitution) for t in term)
        else:
            return term


class InferenceEngine:
    """
    Backward-chaining inference engine for logical reasoning
    """
    def __init__(self, kb: KnowledgeBase, max_depth: int = 10):
        self.kb = kb
        self.max_depth = max_depth
        self.trace: List[str] = []
    
    def query(self, predicate: str, *arguments: str) -> List[Dict[str, Any]]:
        """
        Query the knowledge base and return all valid substitutions
        """
        self.trace = []
        goal = Fact(predicate, tuple(str(arg) for arg in arguments))
        logger.info(f"Querying: {goal}")
        
        results = list(self._prove_goal(goal, {}, 0))
        
        logger.info(f"Query returned {len(results)} result(s)")
        return results
    
    def _prove_goal(self, goal: Fact, substitution: Dict[str, Any], 
                   depth: int) -> List[Dict[str, Any]]:
        """
        Recursively prove a goal using backward chaining
        """
        if depth > self.max_depth:
            return []
        
        self.trace.append("  " * depth + f"Trying to prove: {goal}")
        results = []
        
        # Try to unify with facts
        for fact in self.kb.get_facts_by_predicate(goal.predicate):
            unified_sub = UnificationEngine.unify(
                (goal.predicate, goal.arguments),
                (fact.predicate, fact.arguments),
                substitution.copy()
            )
            
            if unified_sub is not None:
                self.trace.append("  " * depth + f"✓ Unified with fact: {fact}")
                results.append(unified_sub)
        
        # Try to unify with rules
        for rule in self.kb.rules:
            if rule.head.predicate == goal.predicate:
                unified_sub = UnificationEngine.unify(
                    goal.arguments,
                    rule.head.arguments,
                    substitution.copy()
                )
                
                if unified_sub is not None:
                    self.trace.append("  " * depth + f"Trying rule: {rule}")
                    
                    # Prove all body goals
                    body_results = self._prove_body(rule.body, unified_sub, depth + 1)
                    results.extend(body_results)
        
        return results
    
    def _prove_body(self, body: List[Fact], substitution: Dict[str, Any], 
                   depth: int) -> List[Dict[str, Any]]:
        """
        Prove all goals in a rule body
        """
        if not body:
            return [substitution]
        
        first_goal = body[0]
        rest_goals = body[1:]
        
        # Apply current substitution to first goal
        instantiated_goal = Fact(
            first_goal.predicate,
            tuple(UnificationEngine.apply_substitution(arg, substitution) 
                  for arg in first_goal.arguments)
        )
        
        results = []
        for sub in self._prove_goal(instantiated_goal, substitution, depth):
            # Recursively prove remaining goals
            rest_results = self._prove_body(rest_goals, sub, depth)
            results.extend(rest_results)
        
        return results
    
    def get_explanation(self) -> str:
        """Get reasoning trace"""
        return "\n".join(self.trace)


class SymbolicReasoningModule:
    """
    High-level interface for symbolic reasoning
    """
    def __init__(self, max_depth: int = 10):
        self.kb = KnowledgeBase()
        self.engine = InferenceEngine(self.kb, max_depth)
        self._setup_default_rules()
        logger.info("Symbolic Reasoning Module initialized")
    
    def _setup_default_rules(self):
        """Setup common reasoning rules"""
        for rel in ["taller_than", "older_than", "faster_than"]:
            self.kb.add_rule(
                rel, ("X", "Z"),
                [(rel, ("X", "Y")), (rel, ("Y", "Z"))]
            )

        # Transitivity: if A > B and B > C, then A > C
        self.kb.add_rule(
            "larger_than", ("X", "Z"),
            [("larger_than", ("X", "Y")), ("larger_than", ("Y", "Z"))]
        )
        
        # Size comparisons
        self.kb.add_rule(
            "larger_than", ("X", "Y"),
            [("large", ("X",)), ("small", ("Y",))]
        )
        
        self.kb.add_rule(
            "larger_than", ("X", "Y"),
            [("huge", ("X",)), ("medium", ("Y",))]
        )
        
        # Taxonomy rules
        self.kb.add_rule(
            "is_a", ("X", "Z"),
            [("is_a", ("X", "Y")), ("is_a", ("Y", "Z"))]
        )

    def _objects_with(self, color: Optional[str] = None, shape: Optional[str] = None) -> List[str]:
        obj_ids = {fact.arguments[0] for fact in self.kb.get_facts_by_predicate("object")}
        if shape:
            obj_ids &= {fact.arguments[0] for fact in self.kb.get_facts_by_predicate(shape)}
        if color:
            obj_ids &= {fact.arguments[0] for fact in self.kb.get_facts_by_predicate(color)}
        return sorted(obj_ids)

    def _singularize(self, w: str) -> str:
        w = (w or "").strip().lower()
        if w.endswith("ss") or w.endswith("is") or w.endswith("us"):
            return w
        if len(w) > 3 and w.endswith("s"):
            return w[:-1]
        return w

    def _get_area(self, obj_id: str) -> Optional[float]:
        facts = self.kb.get_facts_by_predicate("area")
        for f in facts:
            if len(f.arguments) >= 2 and f.arguments[0] == obj_id:
                try:
                    return float(f.arguments[1])
                except Exception:
                    return None
        return None

    def _get_span(self, obj_id: str) -> Optional[float]:
        facts = self.kb.get_facts_by_predicate("span")
        for f in facts:
            if len(f.arguments) >= 2 and f.arguments[0] == obj_id:
                try:
                    return float(f.arguments[1])
                except Exception:
                    return None
        return None

    def _get_measure(self, obj_id: str) -> Optional[float]:
        facts = self.kb.get_facts_by_predicate("measure")
        for f in facts:
            if len(f.arguments) >= 2 and f.arguments[0] == obj_id:
                try:
                    return float(f.arguments[1])
                except Exception:
                    return None
        return None

    def _get_size_rank(self, obj_id: str) -> Optional[int]:
        # Support both generator sizes (small/medium/large) and perception sizes (tiny..huge)
        size_order = {"tiny": 0, "small": 1, "medium": 2, "large": 3, "huge": 4}
        for size in size_order.keys():
            facts = self.kb.get_facts_by_predicate(size)
            if any(f.arguments[0] == obj_id for f in facts):
                return size_order[size]
        return None

    def _evaluate_all_relation(self, color1: str, shape1: str, relation: str, color2: str, shape2: str) -> Dict[str, Any]:
        group1 = self._objects_with(color=color1, shape=shape1)
        group2 = self._objects_with(color=color2, shape=shape2)
        trace = [f"Group1 ({color1} {shape1}): {group1}", f"Group2 ({color2} {shape2}): {group2}"]

        relation = relation.lower().strip()
        is_larger = relation in {"larger", "bigger", "greater"}
        is_smaller = relation in {"smaller", "less"}
        if not (is_larger or is_smaller):
            trace.append(f"Unsupported relation: {relation}")
            return {"success": False, "trace": trace}

        if not group1 or not group2:
            trace.append("One or both groups are empty")
            return {"success": False, "trace": trace}

        ok = True
        for a in group1:
            ma = self._get_measure(a)
            sa = self._get_span(a)
            aa = self._get_area(a)
            ra = self._get_size_rank(a)
            for b in group2:
                mb = self._get_measure(b)
                sb = self._get_span(b)
                ab = self._get_area(b)
                rb = self._get_size_rank(b)

                if ma is not None and mb is not None:
                    if is_larger and not (ma > mb):
                        ok = False
                        trace.append(f"Violation: {a} (measure {ma:.1f}) not larger than {b} (measure {mb:.1f})")
                    if is_smaller and not (ma < mb):
                        ok = False
                        trace.append(f"Violation: {a} (measure {ma:.1f}) not smaller than {b} (measure {mb:.1f})")
                    continue

                if sa is not None and sb is not None:
                    if is_larger and not (sa > sb):
                        ok = False
                        trace.append(f"Violation: {a} (span {sa:.1f}) not larger than {b} (span {sb:.1f})")
                    if is_smaller and not (sa < sb):
                        ok = False
                        trace.append(f"Violation: {a} (span {sa:.1f}) not smaller than {b} (span {sb:.1f})")
                    continue

                if aa is not None and ab is not None:
                    if is_larger and not (aa > ab):
                        ok = False
                        trace.append(f"Violation: {a} (area {aa:.1f}) not larger than {b} (area {ab:.1f})")
                    if is_smaller and not (aa < ab):
                        ok = False
                        trace.append(f"Violation: {a} (area {aa:.1f}) not smaller than {b} (area {ab:.1f})")
                    continue

                if ra is None or rb is None:
                    ok = False
                    trace.append(f"Missing size/area for comparison: {a} or {b}")
                    continue
                if is_larger and not (ra > rb):
                    ok = False
                    trace.append(f"Violation: {a} (rank {ra}) not larger than {b} (rank {rb})")
                if is_smaller and not (ra < rb):
                    ok = False
                    trace.append(f"Violation: {a} (rank {ra}) not smaller than {b} (rank {rb})")

        trace.append(f"Result: {'TRUE' if ok else 'FALSE'}")
        return {"success": ok, "trace": trace}

    def _evaluate_binary_relation(self, color1: str, shape1: str, relation: str, color2: str, shape2: str) -> Dict[str, Any]:
        group1 = self._objects_with(color=color1, shape=shape1)
        group2 = self._objects_with(color=color2, shape=shape2)
        trace = [f"Obj1 candidates ({color1} {shape1}): {group1}", f"Obj2 candidates ({color2} {shape2}): {group2}"]

        relation = relation.lower().strip()
        is_larger = relation in {"larger", "bigger", "greater"}
        is_smaller = relation in {"smaller", "less"}
        if not (is_larger or is_smaller):
            trace.append(f"Unsupported relation: {relation}")
            return {"success": False, "trace": trace}

        if not group1 or not group2:
            trace.append("One or both objects not found")
            return {"success": False, "trace": trace}

        a = group1[0]
        b = group2[0]
        ma = self._get_measure(a)
        mb = self._get_measure(b)
        if ma is not None and mb is not None:
            ok = (ma > mb) if is_larger else (ma < mb)
            trace.append(f"Comparing {a} (measure {ma:.1f}) vs {b} (measure {mb:.1f}) -> {'TRUE' if ok else 'FALSE'}")
            return {"success": ok, "trace": trace}

        sa = self._get_span(a)
        sb = self._get_span(b)
        if sa is not None and sb is not None:
            ok = (sa > sb) if is_larger else (sa < sb)
            trace.append(f"Comparing {a} (span {sa:.1f}) vs {b} (span {sb:.1f}) -> {'TRUE' if ok else 'FALSE'}")
            return {"success": ok, "trace": trace}

        aa = self._get_area(a)
        ab = self._get_area(b)
        if aa is not None and ab is not None:
            ok = (aa > ab) if is_larger else (aa < ab)
            trace.append(f"Comparing {a} (area {aa:.1f}) vs {b} (area {ab:.1f}) -> {'TRUE' if ok else 'FALSE'}")
            return {"success": ok, "trace": trace}

        ra = self._get_size_rank(a)
        rb = self._get_size_rank(b)
        if ra is None or rb is None:
            trace.append(f"Missing size/area for comparison: {a} or {b}")
            return {"success": False, "trace": trace}

        ok = (ra > rb) if is_larger else (ra < rb)
        trace.append(f"Comparing {a} (rank {ra}) vs {b} (rank {rb}) -> {'TRUE' if ok else 'FALSE'}")
        return {"success": ok, "trace": trace}
    
    def add_objects_from_perception(self, objects: List[Dict]):
        """
        Convert neural perception output to symbolic facts
        """
        for obj in objects:
            obj_id = obj["id"]
            
            # Add object facts
            self.kb.add_fact("object", obj_id)
            self.kb.add_fact(obj["shape"], obj_id)
            self.kb.add_fact(obj["color"], obj_id)
            self.kb.add_fact(obj["size"], obj_id)

            if "bbox" in obj and obj["bbox"] is not None:
                try:
                    x, y, w, h = obj["bbox"]
                    self.kb.add_fact("span", obj_id, f"{float(max(w, h)):.3f}")
                except Exception:
                    pass

            if "measure" in obj and obj["measure"] is not None:
                try:
                    self.kb.add_fact("measure", obj_id, f"{float(obj['measure']):.3f}")
                except Exception:
                    pass

            if "area" in obj:
                try:
                    self.kb.add_fact("area", obj_id, f"{float(obj['area']):.3f}")
                except Exception:
                    pass
            
            if "material" in obj:
                self.kb.add_fact(obj["material"], obj_id)
            
            # Add position facts
            if "position" in obj:
                x, y = obj["position"]["x"], obj["position"]["y"]
                self.kb.add_fact("at_position", obj_id, f"{x:.1f}", f"{y:.1f}")
        
        logger.info(f"Added {len(objects)} objects to knowledge base")
    
    def add_text_premises(self, premises: List[Dict]):
        """
        Add logical premises from text
        """
        for premise in premises:
            if "subject" in premise and "object" in premise:
                pred = premise.get("predicate", "is_a")
                subj = premise["subject"]
                obj = premise["object"]

                if pred == "all_can":
                    cls = self._singularize(subj)
                    action = obj
                    self.kb.add_rule(
                        "can", ("X", action),
                        [("is_a", ("X", cls))]
                    )
                    continue

                if pred == "cannot":
                    cls = self._singularize(subj)
                    action = obj
                    self.kb.add_fact("cannot", cls, action)
                    self.kb.add_rule(
                        "cannot", ("X", action),
                        [("is_a", ("X", cls))]
                    )
                    continue

                self.kb.add_fact(pred, subj, obj)
    
    def reason(self, query: str) -> Dict[str, Any]:
        """
        Perform logical reasoning on a query
        
        Args:
            query: Natural language query
            
        Returns:
            Reasoning result with answer and explanation
        """
        # Parse query
        parsed_query = self._parse_query(query)
        
        if not parsed_query:
            return {
                "success": False,
                "answer": None,
                "explanation": "Could not parse query"
            }

        if parsed_query["predicate"] == "who_is_a":
            (cls,) = parsed_query["arguments"]
            results = self.engine.query("is_a", "X", cls)
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"Who is a {cls}: {', '.join(values) if values else '(none)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(none)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "what_is":
            (ent,) = parsed_query["arguments"]
            results = self.engine.query("is_a", ent, "X")
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"What is {ent}: {', '.join(values) if values else '(none)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(none)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "where_is":
            (ent,) = parsed_query["arguments"]
            results = self.engine.query("at", ent, "X")
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"Where is {ent}: {', '.join(values) if values else '(unknown)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(unknown)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "who_at":
            (place,) = parsed_query["arguments"]
            results = self.engine.query("at", "X", place)
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"Who is at {place}: {', '.join(values) if values else '(none)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(none)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "who_has":
            (thing,) = parsed_query["arguments"]
            results = self.engine.query("has", "X", thing)
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"Who has {thing}: {', '.join(values) if values else '(none)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(none)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "what_has":
            (ent,) = parsed_query["arguments"]
            results = self.engine.query("has", ent, "X")
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"What does {ent} have: {', '.join(values) if values else '(none)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(none)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "when_event":
            (evt,) = parsed_query["arguments"]
            results = self.engine.query("at_time", evt, "X")
            values = sorted({r.get("X") for r in results if r.get("X")})
            self.engine.trace = [f"When is {evt}: {', '.join(values) if values else '(unknown)'}"]
            return {
                "success": len(values) > 0,
                "answer": ", ".join(values) if values else "(unknown)",
                "substitutions": results,
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "can":
            subject, action = parsed_query["arguments"]
            # Use inference engine so rules like can(X, fly) :- is_a(X, bird) apply.
            blocked = self.engine.query("cannot", subject, action)
            allowed = self.engine.query("can", subject, action)

            is_blocked = len(blocked) > 0
            is_allowed = len(allowed) > 0

            if is_blocked:
                self.engine.trace = [f"Found cannot({subject}, {action}) -> answer FALSE"]
                return {
                    "success": False,
                    "answer": "FALSE",
                    "substitutions": [],
                    "explanation": self.engine.get_explanation(),
                    "knowledge_base": self.kb.to_prolog_format()
                }

            if is_allowed:
                self.engine.trace = [f"Found can({subject}, {action}) -> answer TRUE"]
                return {
                    "success": True,
                    "answer": "TRUE",
                    "substitutions": [],
                    "explanation": self.engine.get_explanation(),
                    "knowledge_base": self.kb.to_prolog_format()
                }

            self.engine.trace = [f"No can/cannot facts for ({subject}, {action}) -> default FALSE"]
            return {
                "success": False,
                "answer": "FALSE",
                "substitutions": [],
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "exists_color_shape":
            color, shape = parsed_query["arguments"]
            matches = self._objects_with(color=color, shape=shape)
            success = len(matches) > 0
            self.engine.trace = [f"Checking existence of {color} {shape}: {len(matches)} match(es)"]
            return {
                "success": success,
                "answer": "TRUE" if success else "FALSE",
                "substitutions": [{"X": obj_id} for obj_id in matches],
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "count_color_shape":
            color, shape = parsed_query["arguments"]
            matches = self._objects_with(color=color, shape=shape)
            self.engine.trace = [f"Counting {color} {shape}: {len(matches)}"]
            return {
                "success": True,
                "answer": str(len(matches)),
                "substitutions": [],
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "count_shape":
            (shape,) = parsed_query["arguments"]
            matches = self._objects_with(shape=shape)
            self.engine.trace = [f"Counting {shape}: {len(matches)}"]
            return {
                "success": True,
                "answer": str(len(matches)),
                "substitutions": [],
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "list_shapes":
            shapes = sorted({fact.predicate for fact in self.kb.facts if fact.predicate in {
                "circle", "square", "triangle", "rectangle", "pentagon", "hexagon"
            }})
            self.engine.trace = [f"Shapes present: {', '.join(shapes) if shapes else '(none)'}"]
            return {
                "success": True,
                "answer": ", ".join(shapes) if shapes else "(none)",
                "substitutions": [],
                "explanation": self.engine.get_explanation(),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "all_relation":
            color1, shape1, relation, color2, shape2 = parsed_query["arguments"]
            result = self._evaluate_all_relation(color1, shape1, relation, color2, shape2)
            return {
                "success": result["success"],
                "answer": "TRUE" if result["success"] else "FALSE",
                "substitutions": [],
                "explanation": "\n".join(result["trace"]),
                "knowledge_base": self.kb.to_prolog_format()
            }

        if parsed_query["predicate"] == "binary_relation":
            color1, shape1, relation, color2, shape2 = parsed_query["arguments"]
            result = self._evaluate_binary_relation(color1, shape1, relation, color2, shape2)
            return {
                "success": result["success"],
                "answer": "TRUE" if result["success"] else "FALSE",
                "substitutions": [],
                "explanation": "\n".join(result["trace"]),
                "knowledge_base": self.kb.to_prolog_format()
            }
        
        # Execute query
        results = self.engine.query(
            parsed_query["predicate"],
            *parsed_query["arguments"]
        )
        
        # Format response
        return {
            "success": len(results) > 0,
            "answer": "TRUE" if results else "FALSE",
            "substitutions": results,
            "explanation": self.engine.get_explanation(),
            "knowledge_base": self.kb.to_prolog_format()
        }
    
    def _parse_query(self, query: str) -> Optional[Dict]:
        """
        Parse natural language query into logical form
        """
        query = query.lower().strip()
        query = re.sub(r"[^a-z0-9_\s]", "", query)
        query = re.sub(r"\s+", " ", query).strip()

        # WH / list queries
        match = re.match(r"who (?:is|are) an? (\w+)", query)
        if match:
            return {"predicate": "who_is_a", "arguments": [match.group(1)]}

        match = re.match(r"who is (?:in|at) (\w+)", query)
        if match:
            return {"predicate": "who_at", "arguments": [match.group(1)]}

        match = re.match(r"who has (\w+)", query)
        if match:
            return {"predicate": "who_has", "arguments": [match.group(1)]}

        match = re.match(r"who are (\w+?)(?:s)?", query)
        if match:
            return {"predicate": "who_is_a", "arguments": [match.group(1)]}

        match = re.match(r"which (\w+?)(?:s)? are (\w+)", query)
        if match:
            return {"predicate": "who_is_a", "arguments": [match.group(2)]}

        match = re.match(r"what is (\w+)", query)
        if match:
            return {"predicate": "what_is", "arguments": [match.group(1)]}

        match = re.match(r"what does (\w+) have", query)
        if match:
            return {"predicate": "what_has", "arguments": [match.group(1)]}

        match = re.match(r"where is (\w+)", query)
        if match:
            return {"predicate": "where_is", "arguments": [match.group(1)]}

        match = re.match(r"when (?:did|does) (\w+) (?:happen|occur)", query)
        if match:
            return {"predicate": "when_event", "arguments": [match.group(1)]}

        match = re.match(r"when is (\w+)", query)
        if match:
            return {"predicate": "when_event", "arguments": [match.group(1)]}

        # Pattern: "is there a COLOR SHAPE"
        match = re.match(r"is there an? (\w+) (\w+)", query)
        if match:
            return {
                "predicate": "exists_color_shape",
                "arguments": [match.group(1), match.group(2)]
            }

        # Pattern: "how many COLOR SHAPEs are there"
        match = re.match(r"how many (\w+) (\w+?)(?:s)? are there", query)
        if match:
            return {
                "predicate": "count_color_shape",
                "arguments": [match.group(1), match.group(2)]
            }

        # Pattern: "how many SHAPEs are there"
        match = re.match(r"how many (\w+?)(?:s)? are there", query)
        if match:
            return {
                "predicate": "count_shape",
                "arguments": [match.group(1)]
            }

        # Pattern: "what shapes are in the image"
        match = re.match(r"what shapes are in the image", query)
        if match:
            return {
                "predicate": "list_shapes",
                "arguments": []
            }

        # Text pattern: "can X Y"
        match = re.match(r"can (\w+) (\w+)", query)
        if match:
            subj = self._singularize(match.group(1))
            return {
                "predicate": "can",
                "arguments": [subj, match.group(2)]
            }

        # Yes/No: location and possession
        match = re.match(r"is (\w+) (?:in|at) (\w+)", query)
        if match:
            return {"predicate": "at", "arguments": [match.group(1), match.group(2)]}

        match = re.match(r"does (\w+) have (\w+)", query)
        if match:
            return {"predicate": "has", "arguments": [match.group(1), match.group(2)]}

        match = re.match(r"does (\w+) like (\w+)", query)
        if match:
            return {"predicate": "likes", "arguments": [match.group(1), match.group(2)]}

        # Text pattern: "is X RELATION than Y" -> relation_than(X, Y)
        match = re.match(r"is (\w+) (\w+) than (\w+)", query)
        if match:
            subj, rel, obj = match.groups()
            return {
                "predicate": f"{rel}_than",
                "arguments": [subj, obj]
            }
        
        # Pattern: "is X a Y"
        match = re.match(r"is (?!there\b)(\w+) an? (\w+)", query)
        if match:
            return {
                "predicate": "is_a",
                "arguments": [match.group(1), match.group(2)]
            }

        # Text pattern: "is X Y" (no article)
        match = re.match(r"is (?!there\b)(\w+) (\w+)", query)
        if match:
            return {
                "predicate": "is_a",
                "arguments": [match.group(1), match.group(2)]
            }
        
        # Pattern: "are all X Y than Z"
        match = re.match(r"are all (\w+) (\w+)s? (\w+) than (\w+) (\w+)s?", query)
        if match:
            color1, shape1, relation, color2, shape2 = match.groups()
            # This requires checking all objects - more complex
            return {
                "predicate": "all_relation",
                "arguments": [color1, self._singularize(shape1), relation, color2, self._singularize(shape2)]
            }

        # Pattern: "is the COLOR SHAPE RELATION than the COLOR SHAPE"
        match = re.match(r"is the (\w+) (\w+) (\w+) than the (\w+) (\w+)", query)
        if match:
            color1, shape1, relation, color2, shape2 = match.groups()
            return {
                "predicate": "binary_relation",
                "arguments": [color1, self._singularize(shape1), relation, color2, self._singularize(shape2)]
            }
        
        # Default: try to extract predicate and arguments
        words = query.split()
        if len(words) >= 2:
            return {
                "predicate": words[0],
                "arguments": words[1:]
            }
        
        return None
    
    def reset(self):
        """Clear knowledge base"""
        self.kb.clear_facts()
        logger.info("Knowledge base cleared")
