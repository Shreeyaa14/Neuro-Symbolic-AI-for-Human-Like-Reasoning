"""
Interactive Web Interface using Gradio
User-friendly interface for the Neuro-Symbolic Reasoning System
"""

import os
import gradio as gr
from PIL import Image
import json
from pathlib import Path
import socket
from loguru import logger

from neuro_symbolic_system import NeuroSymbolicSystem
from dataset_generator import VisualDatasetGenerator, TextDatasetGenerator
import config


class WebInterface:
    """
    Gradio-based web interface for the system
    """
    def __init__(self):
        logger.info("Initializing Web Interface...")
        self.system = NeuroSymbolicSystem(device=config.NEURAL_CONFIG["device"])
        self.visual_gen = VisualDatasetGenerator()
        logger.success("Web Interface ready!")
    
    def process_visual_reasoning(self, image, query, generated_objects):
        """
        Process visual reasoning query from web interface
        """
        if image is None:
            return "Please upload an image!", "", "", None
        
        if not query or query.strip() == "":
            return "Please enter a question!", "", "", None
        
        try:
            temp_path = config.DATA_DIR / "temp_upload.png"
            temp_path.parent.mkdir(exist_ok=True, parents=True)

            if isinstance(image, str):
                Image.open(image).save(temp_path)
            else:
                image.save(temp_path)

            objects = None
            if isinstance(generated_objects, list) and len(generated_objects) > 0:
                objects = generated_objects
            else:
                objects = self.system.neural_vision.detect_objects(str(temp_path))

            self.system.symbolic.reset()
            self.system.symbolic.add_objects_from_perception(objects)
            reasoning_result = self.system.symbolic.reason(query)

            answer = f"**Answer:** {reasoning_result['answer']}"

            objects_text = "**Detected Objects:**\n"
            for obj in objects:
                conf = obj.get("confidence", 1.0)
                objects_text += f"- {obj['id']}: {obj['color']} {obj['shape']} ({obj['size']}) - Confidence: {conf:.2%}\n"

            explanation = f"**Reasoning Trace:**\n```\n{reasoning_result.get('explanation','')}\n```"
            kb_text = f"\n**Knowledge Base (Prolog):**\n```prolog\n{reasoning_result.get('knowledge_base','')}\n```"
            full_explanation = explanation + kb_text

            vis_image = None
            try:
                vis_path = config.OUTPUTS_DIR / "detection_visualization.png"
                self.system.neural_vision.visualize_detection(str(temp_path), objects, str(vis_path))
                vis_image = Image.open(vis_path)
            except Exception:
                vis_image = None

            return answer, objects_text, full_explanation, vis_image
            
        except Exception as e:
            logger.error(f"Error in visual reasoning: {e}")
            return f"Error: {str(e)}", "", "", None
    
    def process_text_reasoning(self, premises, query):
        """
        Process text-based reasoning query
        """
        if not premises or premises.strip() == "":
            return "Please enter premises!", ""
        
        if not query or query.strip() == "":
            return "Please enter a question!", ""
        
        try:
            result = self.system.process_text_query(premises, query)
            
            # Format response
            answer = f"**Answer:** {result['reasoning']['answer']}"
            
            # Parsing results
            entities_text = "\n**Extracted Entities:**\n"
            entities_text += f"- {', '.join(result['entities']['entities'])}\n"
            
            entities_text += "\n**Extracted Relations:**\n"
            for rel in result['entities']['relations']:
                entities_text += f"- {rel['subject']} → {rel['predicate']} → {rel['object']}\n"
            
            # Reasoning trace
            explanation = f"\n**Reasoning Trace:**\n```\n{result['reasoning']['explanation']}\n```"
            
            # Knowledge base
            kb_text = f"\n**Knowledge Base (Prolog):**\n```prolog\n{result['reasoning']['knowledge_base']}\n```"
            
            full_response = answer + entities_text + explanation + kb_text
            
            # Metrics
            metrics_text = f"\n**Metrics:**\n- Inference Time: {result['metrics']['inference_time']:.3f}s"
            full_response += metrics_text
            
            return full_response, ""
            
        except Exception as e:
            logger.error(f"Error in text reasoning: {e}")
            return f"Error: {str(e)}", ""
    
    def generate_random_image(self):
        """
        Generate a random test image
        """
        try:
            image, objects = self.visual_gen.generate_image(num_objects=4)
            
            # Save temporarily
            temp_path = config.DATA_DIR / "generated_image.png"
            temp_path.parent.mkdir(exist_ok=True, parents=True)
            image.save(temp_path)
            
            # Create description
            desc = "**Generated Objects:**\n"
            for obj in objects:
                desc += f"- {obj['color']} {obj['shape']} ({obj['size']})\n"
            
            # Suggest questions
            questions = [
                f"Is there a {objects[0]['color']} {objects[0]['shape']}?",
                f"How many {objects[0]['shape']}s are there?",
                "What shapes are in the image?"
            ]
            
            desc += "\n**Try asking:**\n"
            for q in questions[:2]:
                desc += f"- {q}\n"
            
            # Reset answer/trace/visualization when generating a new image
            return image, desc, "", "", None, objects
            
        except Exception as e:
            logger.error(f"Error generating image: {e}")
            return None, f"Error: {str(e)}", "", "", None, None

    def clear_visual(self):
        return None, "", "", "", "", None, None

    def on_user_image_upload(self, image):
        # If a user uploads a new image, discard any previously generated ground-truth objects.
        return "", None
    
    def create_interface(self):
        """
        Create and configure Gradio interface
        """
        # Custom CSS for better styling
        custom_css = """
        .gradio-container {
            font-family: 'Arial', sans-serif;
        }
        .output-text {
            font-size: 16px;
            line-height: 1.6;
        }
        """
        
        with gr.Blocks(
            title="Neuro-Symbolic Reasoning System",
            theme=gr.themes.Soft(),
            css=custom_css
        ) as interface:
            
            gr.Markdown("""
            # 🧠 Neuro-Symbolic Reasoning System
            ### Integrating Neural Perception and Symbolic Logic for Explainable AI
            
            This system combines:
            - **System 1 (Neural)**: Fast, intuitive perception using deep learning
            - **System 2 (Symbolic)**: Slow, deliberate reasoning using logic
            """)
            
            with gr.Tabs():
                # Tab 1: Visual Reasoning
                with gr.Tab("🖼️ Visual Reasoning"):
                    gr.Markdown("""
                    Upload an image and ask questions about the objects in it.
                    The system will detect objects and use logical reasoning to answer your query.
                    """)
                    
                    with gr.Row():
                        with gr.Column(scale=1):
                            generated_objects_state = gr.State(value=None)
                            visual_input_image = gr.Image(
                                label="Upload Image",
                                type="pil"
                            )
                            visual_query = gr.Textbox(
                                label="Your Question",
                                placeholder="e.g., Is there a red circle?",
                                lines=2
                            )
                            
                            with gr.Row():
                                visual_submit = gr.Button("🔍 Analyze", variant="primary")
                                visual_clear = gr.Button("🔄 Clear")
                                gen_image_btn = gr.Button("🎲 Generate Random Image")
                            
                            gr.Markdown("**Example Questions:**")
                            gr.Examples(
                                examples=[
                                    ["Is there a red circle?"],
                                    ["How many blue squares are there?"],
                                    ["Are all red circles larger than blue squares?"],
                                ],
                                inputs=visual_query
                            )
                        
                        with gr.Column(scale=1):
                            visual_answer = gr.Markdown(label="Answer")
                            visual_objects = gr.Markdown(label="Detected Objects")
                            visual_visualization = gr.Image(label="Object Detection")
                    
                    with gr.Accordion("🔍 Detailed Explanation", open=False):
                        visual_explanation = gr.Markdown()
                    
                    visual_submit.click(
                        fn=self.process_visual_reasoning,
                        inputs=[visual_input_image, visual_query, generated_objects_state],
                        outputs=[visual_answer, visual_objects, visual_explanation, visual_visualization]
                    )
                    
                    gen_image_btn.click(
                        fn=self.generate_random_image,
                        inputs=[],
                        outputs=[visual_input_image, visual_objects, visual_answer, visual_explanation, visual_visualization, generated_objects_state]
                    )

                    visual_input_image.upload(
                        fn=self.on_user_image_upload,
                        inputs=[visual_input_image],
                        outputs=[visual_objects, generated_objects_state]
                    )

                    visual_clear.click(
                        fn=self.clear_visual,
                        inputs=[],
                        outputs=[visual_input_image, visual_query, visual_answer, visual_objects, visual_explanation, visual_visualization, generated_objects_state]
                    )
                
                # Tab 2: Text Reasoning
                with gr.Tab("📝 Text Reasoning"):
                    gr.Markdown("""
                    Enter logical premises and ask questions.
                    The system will parse the text and perform logical inference.
                    """)
                    
                    with gr.Row():
                        with gr.Column(scale=1):
                            text_premises = gr.Textbox(
                                label="Premises (one per line)",
                                placeholder="e.g., All mammals are animals.\nAll dogs are mammals.",
                                lines=5
                            )
                            text_query = gr.Textbox(
                                label="Question",
                                placeholder="e.g., Is dog an animal?",
                                lines=2
                            )
                            
                            with gr.Row():
                                text_submit = gr.Button("🔍 Reason", variant="primary")
                                text_clear = gr.Button("🔄 Clear")
                            
                            gr.Markdown("**Example Scenarios:**")
                            gr.Examples(
                                examples=[
                                    [
                                        "All mammals are animals.\nAll dogs are mammals.",
                                        "Is dog an animal?"
                                    ],
                                    [
                                        "Alice is taller than Bob.\nBob is taller than Charlie.",
                                        "Is Alice taller than Charlie?"
                                    ],
                                    [
                                        "All birds can fly.\nPenguins are birds.",
                                        "Can penguin fly?"
                                    ],
                                ],
                                inputs=[text_premises, text_query]
                            )
                        
                        with gr.Column(scale=1):
                            text_output = gr.Markdown(label="Result")
                    
                    with gr.Accordion("🔍 Detailed Analysis", open=False):
                        text_analysis = gr.Markdown()
                    
                    text_submit.click(
                        fn=self.process_text_reasoning,
                        inputs=[text_premises, text_query],
                        outputs=[text_output, text_analysis]
                    )
                
                # Tab 3: About
                with gr.Tab("ℹ️ About"):
                    gr.Markdown("""
                    ## About This System
                    
                    ### Architecture
                    This neuro-symbolic system implements **Dual-Process Theory** from cognitive science:
                    
                    1. **System 1 (Neural Perception)**:
                       - Uses ResNet/Vision Transformers for object detection
                       - Processes images to extract objects and their attributes
                       - Fast, intuitive, perceptual processing
                    
                    2. **System 2 (Symbolic Reasoning)**:
                       - Uses logic programming (Prolog-style) for inference
                       - Performs deliberate, step-by-step reasoning
                       - Provides explainable conclusions
                    
                    ### Features
                    - ✅ **Explainable AI**: Full reasoning traces
                    - ✅ **Hybrid Approach**: Best of neural and symbolic
                    - ✅ **Multiple Modalities**: Visual and text reasoning
                    - ✅ **Real-time Processing**: Fast inference
                    
                    ### Technical Stack
                    - **Deep Learning**: PyTorch, Transformers
                    - **Computer Vision**: OpenCV, Pillow
                    - **Symbolic AI**: Custom inference engine
                    - **Interface**: Gradio
                    
                    ### Use Cases
                    - Educational AI systems
                    - Transparent decision-making
                    - Visual question answering
                    - Logical reasoning tasks
                    - Cognitive science research
                    
                    ---
                    **Academic Project**: MSc Cognitive Science
                    
                    **Project Title**: A Neuro-Symbolic Architecture for Human-Like Reasoning Based on Dual-Process Cognitive Theory
                    """)
            
            return interface
    
    def launch(self, share=False, port=7860):
        """
        Launch the web interface
        """
        interface = self.create_interface()
        logger.info(f"Launching web interface on port {port}...")

        def is_port_in_use(host: str, p: int) -> bool:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s.settimeout(0.15)
                return s.connect_ex((host, int(p))) == 0
            except Exception:
                return False
            finally:
                try:
                    s.close()
                except Exception:
                    pass

        def is_port_free(p: int) -> bool:
            return (not is_port_in_use("127.0.0.1", p)) and (not is_port_in_use("0.0.0.0", p))

        # Prefer higher ports to avoid collisions with previously started Gradio sessions.
        candidate_ports = (
            list(range(9000, 9101)) +
            list(range(12000, 12101)) +
            list(range(int(port), int(port) + 51))
        )
        chosen = None
        for p in candidate_ports:
            if is_port_free(int(p)):
                chosen = int(p)
                break

        if chosen is not None:
            logger.info(f"Using free port {chosen} for Gradio")
            local_url = interface.launch(
                share=share,
                server_port=chosen,
                server_name="0.0.0.0"
            )
            logger.info(f"Gradio running at: {local_url}")
            return

        logger.warning("No free port found in scan range; falling back to Gradio auto port selection")
        local_url = interface.launch(share=share, server_name="0.0.0.0")
        logger.info(f"Gradio running at: {local_url}")


def main():
    """
    Main entry point for web interface
    """
    web_interface = WebInterface()
    env_port = os.getenv("GRADIO_SERVER_PORT")
    web_interface.launch(
        share=config.UI_CONFIG["share"],
        port=int(env_port) if env_port else config.UI_CONFIG["port"]
    )


if __name__ == "__main__":
    main()
