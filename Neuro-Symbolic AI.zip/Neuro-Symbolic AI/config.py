"""
Configuration file for Neuro-Symbolic Reasoning System
"""

import os
from pathlib import Path

# Project Paths
PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"
LOGS_DIR = PROJECT_ROOT / "logs"

# Create directories if they don't exist
for dir_path in [DATA_DIR, MODELS_DIR, OUTPUTS_DIR, LOGS_DIR]:
    dir_path.mkdir(exist_ok=True, parents=True)

# Neural Network Configuration
NEURAL_CONFIG = {
    "vision_model": "resnet50",  # Can be: resnet50, vit_base, efficientnet
    "text_model": "bert-base-uncased",
    "image_size": 224,
    "batch_size": 32,
    "learning_rate": 0.001,
    "num_epochs": 50,
    "device": "cuda" if os.path.exists("/dev/nvidia0") else "cpu",
}

# Symbolic Reasoning Configuration
SYMBOLIC_CONFIG = {
    "engine": "prolog",  # prolog or custom
    "max_inference_depth": 10,
    "timeout": 5.0,  # seconds
    "enable_explanation": True,
}

# Dataset Configuration
DATASET_CONFIG = {
    "clevr_path": DATA_DIR / "clevr",
    "custom_visual_path": DATA_DIR / "custom_visual",
    "text_reasoning_path": DATA_DIR / "text_reasoning",
    "train_split": 0.7,
    "val_split": 0.15,
    "test_split": 0.15,
}

# Logging Configuration
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
    "rotation": "10 MB",
}

# Evaluation Metrics
METRICS = [
    "accuracy",
    "precision",
    "recall",
    "f1_score",
    "explanation_completeness",
    "inference_time",
]

# UI Configuration
UI_CONFIG = {
    "theme": "default",
    "port": 7860,
    "share": False,
    "examples_per_task": 5,
}

# Object Detection Classes
OBJECT_CLASSES = {
    "shapes": ["circle", "square", "triangle", "rectangle", "pentagon", "hexagon"],
    "colors": ["red", "blue", "green", "yellow", "purple", "orange", "cyan", "magenta"],
    "sizes": ["tiny", "small", "medium", "large", "huge"],
    "materials": ["metal", "rubber", "wood", "plastic", "glass"],
}

# Logical Reasoning Templates
REASONING_TEMPLATES = {
    "comparison": [
        "Is {obj1} {relation} than {obj2}?",
        "Are all {color} {shape}s {relation} than {color2} {shape2}s?",
    ],
    "counting": [
        "How many {color} {shape}s are there?",
        "Count all {size} objects.",
    ],
    "existence": [
        "Is there a {color} {shape}?",
        "Does a {size} {material} object exist?",
    ],
    "logical": [
        "If all {A} are {B}, and all {B} are {C}, then are all {A} {C}?",
        "Given that {premise}, what can we conclude about {query}?",
    ],
}
