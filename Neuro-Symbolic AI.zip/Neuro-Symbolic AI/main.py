"""
Main Application Entry Point
Command-line interface for the Neuro-Symbolic Reasoning System
"""

import argparse
import sys
from pathlib import Path
from loguru import logger

import config
from neuro_symbolic_system import NeuroSymbolicSystem
from dataset_generator import generate_all_datasets
from evaluator import run_full_evaluation
from web_interface import WebInterface


def setup_logging():
    """Configure logging"""
    logger.remove()
    logger.add(
        sys.stderr,
        format=config.LOGGING_CONFIG["format"],
        level=config.LOGGING_CONFIG["level"],
        colorize=True
    )
    logger.add(
        config.LOGS_DIR / "app_{time}.log",
        rotation=config.LOGGING_CONFIG["rotation"],
        level="DEBUG"
    )


def run_demo(args):
    """
    Run interactive demo
    """
    logger.info("Starting demo mode...")
    
    # Initialize system
    system = NeuroSymbolicSystem(device=args.device)
    
    # Generate sample data if needed
    if not (config.DATA_DIR / "custom_visual" / "dataset.json").exists():
        logger.info("Generating sample datasets...")
        generate_all_datasets()
    
    # Load a sample image
    sample_images = list((config.DATA_DIR / "custom_visual" / "images").glob("*.png"))
    
    if sample_images:
        sample_image = sample_images[0]
        logger.info(f"Using sample image: {sample_image}")
        
        # Example visual query
        result = system.process_visual_query(
            str(sample_image),
            "Is there a red circle?",
            visualize=True
        )
        
        # Print report
        report = system.generate_report(result)
        print(report)
        
        # Save result
        system.save_result(result, "demo_result.json")
    
    # Example text query
    logger.info("\n" + "="*70)
    logger.info("Text Reasoning Example")
    logger.info("="*70 + "\n")
    
    text_result = system.process_text_query(
        "All mammals are animals. All dogs are mammals.",
        "Is dog an animal?"
    )
    
    text_report = system.generate_report(text_result)
    print(text_report)
    
    logger.success("Demo completed!")


def generate_datasets(args):
    """
    Generate synthetic datasets
    """
    logger.info(f"Generating datasets with {args.num_samples} samples each...")
    
    from dataset_generator import VisualDatasetGenerator, TextDatasetGenerator
    
    # Visual dataset
    visual_gen = VisualDatasetGenerator()
    visual_dataset = visual_gen.generate_dataset(num_images=args.num_samples)
    
    # Text dataset
    text_gen = TextDatasetGenerator()
    text_dataset = text_gen.generate_dataset(num_examples=args.num_samples)
    
    logger.success(f"Datasets generated in {config.DATA_DIR}")


def evaluate_system(args):
    """
    Run full evaluation
    """
    logger.info("Starting evaluation...")
    
    # Check if datasets exist
    visual_dataset = config.DATA_DIR / "custom_visual" / "dataset.json"
    text_dataset = config.DATA_DIR / "text_reasoning" / "dataset.json"
    
    if not visual_dataset.exists() or not text_dataset.exists():
        logger.warning("Datasets not found. Generating...")
        generate_all_datasets()
    
    # Initialize system
    system = NeuroSymbolicSystem(device=args.device)
    
    # Run evaluation
    visual_metrics, text_metrics = run_full_evaluation(system)
    
    logger.success("Evaluation completed!")
    logger.info(f"Results saved in {config.OUTPUTS_DIR}")


def launch_web_interface(args):
    """
    Launch web interface
    """
    logger.info("Launching web interface...")
    
    # Ensure datasets exist
    if not (config.DATA_DIR / "custom_visual" / "dataset.json").exists():
        logger.info("Generating sample datasets...")
        generate_all_datasets()
    
    # Launch interface
    web = WebInterface()
    web.launch(share=args.share, port=args.port)


def run_inference(args):
    """
    Run inference on specific input
    """
    logger.info("Running inference...")
    
    system = NeuroSymbolicSystem(device=args.device)
    
    if args.mode == "visual":
        if not args.image:
            logger.error("Image path required for visual reasoning")
            return
        
        result = system.process_visual_query(
            args.image,
            args.query,
            visualize=True
        )
    else:
        if not args.text:
            logger.error("Text premises required for text reasoning")
            return
        
        result = system.process_text_query(
            args.text,
            args.query
        )
    
    # Print and save result
    report = system.generate_report(result)
    print(report)
    
    output_file = f"{args.mode}_inference_result.json"
    system.save_result(result, output_file)
    logger.success(f"Result saved to {config.OUTPUTS_DIR / output_file}")


def main():
    """
    Main entry point with argument parsing
    """
    setup_logging()
    
    parser = argparse.ArgumentParser(
        description="Neuro-Symbolic Reasoning System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Launch web interface
  python main.py web
  
  # Run demo
  python main.py demo
  
  # Generate datasets
  python main.py generate --num-samples 100
  
  # Evaluate system
  python main.py evaluate
  
  # Run inference
  python main.py infer --mode visual --image path/to/image.png --query "Is there a red circle?"
  python main.py infer --mode text --text "All dogs are animals." --query "Is dog an animal?"
        """
    )
    
    parser.add_argument(
        "--device",
        type=str,
        default=config.NEURAL_CONFIG["device"],
        choices=["cpu", "cuda"],
        help="Device to run models on"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Web interface command
    web_parser = subparsers.add_parser("web", help="Launch web interface")
    web_parser.add_argument("--port", type=int, default=7860, help="Port number")
    web_parser.add_argument("--share", action="store_true", help="Create public link")
    
    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run interactive demo")
    
    # Generate command
    gen_parser = subparsers.add_parser("generate", help="Generate datasets")
    gen_parser.add_argument(
        "--num-samples",
        type=int,
        default=50,
        help="Number of samples to generate"
    )
    
    # Evaluate command
    eval_parser = subparsers.add_parser("evaluate", help="Evaluate system")
    
    # Inference command
    infer_parser = subparsers.add_parser("infer", help="Run inference")
    infer_parser.add_argument(
        "--mode",
        type=str,
        required=True,
        choices=["visual", "text"],
        help="Reasoning mode"
    )
    infer_parser.add_argument("--image", type=str, help="Path to image (for visual mode)")
    infer_parser.add_argument("--text", type=str, help="Text premises (for text mode)")
    infer_parser.add_argument("--query", type=str, required=True, help="Query question")
    
    args = parser.parse_args()
    
    # Display banner
    print("""
    ╔══════════════════════════════════════════════════════════════════╗
    ║                                                                  ║
    ║        NEURO-SYMBOLIC REASONING SYSTEM                          ║
    ║        Dual-Process Cognitive Architecture                      ║
    ║                                                                  ║
    ╚══════════════════════════════════════════════════════════════════╝
    """)
    
    # Execute command
    if args.command == "web":
        launch_web_interface(args)
    elif args.command == "demo":
        run_demo(args)
    elif args.command == "generate":
        generate_datasets(args)
    elif args.command == "evaluate":
        evaluate_system(args)
    elif args.command == "infer":
        run_inference(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
