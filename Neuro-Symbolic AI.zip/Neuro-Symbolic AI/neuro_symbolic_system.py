"""
Integrated Neuro-Symbolic Reasoning System
Combines neural perception (System 1) with symbolic reasoning (System 2)
"""

import os
from typing import Dict, List, Any, Optional
from pathlib import Path
import json
import time
from loguru import logger

from neural_module import NeuralPerceptionModule, TextPerceptionModule
from symbolic_module import SymbolicReasoningModule
import config


class NeuroSymbolicSystem:
    """
    Main system integrating neural and symbolic components
    """
    def __init__(self, device: str = "cpu"):
        logger.info("Initializing Neuro-Symbolic Reasoning System...")
        
        # Initialize modules
        self.neural_vision = NeuralPerceptionModule(
            model_name=config.NEURAL_CONFIG["vision_model"],
            device=device
        )
        self.neural_text = TextPerceptionModule(
            model_name=config.NEURAL_CONFIG["text_model"]
        )
        self.symbolic = SymbolicReasoningModule(
            max_depth=config.SYMBOLIC_CONFIG["max_inference_depth"]
        )
        
        self.device = device
        logger.success("System initialized successfully!")
    
    def process_visual_query(self, image_path: str, query: str, 
                           visualize: bool = True) -> Dict[str, Any]:
        """
        Process a visual reasoning query
        
        Args:
            image_path: Path to input image
            query: Natural language question about the image
            visualize: Whether to create visualization
            
        Returns:
            Complete reasoning result
        """
        logger.info(f"Processing visual query: {query}")
        start_time = time.time()
        
        # Step 1: Neural Perception (System 1)
        logger.info("Step 1: Neural Perception (System 1)")
        objects = self.neural_vision.detect_objects(image_path)
        
        # Visualize detection if requested
        if visualize:
            vis_path = config.OUTPUTS_DIR / "detection_visualization.png"
            self.neural_vision.visualize_detection(image_path, objects, str(vis_path))
        
        # Step 2: Symbol Generation
        logger.info("Step 2: Symbol Generation")
        self.symbolic.reset()
        self.symbolic.add_objects_from_perception(objects)
        
        # Step 3: Symbolic Reasoning (System 2)
        logger.info("Step 3: Symbolic Reasoning (System 2)")
        reasoning_result = self.symbolic.reason(query)
        
        # Calculate metrics
        inference_time = time.time() - start_time
        
        # Compile results
        result = {
            "query": query,
            "image_path": image_path,
            "detected_objects": objects,
            "reasoning": reasoning_result,
            "metrics": {
                "num_objects": len(objects),
                "inference_time": inference_time,
                "success": reasoning_result["success"]
            },
            "visualization_path": str(vis_path) if visualize else None
        }
        
        logger.success(f"Query processed in {inference_time:.2f}s - Answer: {reasoning_result['answer']}")
        return result
    
    def process_text_query(self, text: str, query: str) -> Dict[str, Any]:
        """
        Process a text-based reasoning query
        
        Args:
            text: Input text with premises
            query: Question to answer
            
        Returns:
            Reasoning result
        """
        logger.info(f"Processing text query: {query}")
        start_time = time.time()
        
        # Step 1: Parse text (System 1)
        logger.info("Step 1: Text Parsing (System 1)")
        premises = self.neural_text.parse_premises(text)
        entities = self.neural_text.extract_entities(text)
        
        # Step 2: Convert to symbolic form
        logger.info("Step 2: Symbol Generation")
        self.symbolic.reset()
        self.symbolic.add_text_premises(entities["relations"])
        
        # Step 3: Reason (System 2)
        logger.info("Step 3: Logical Reasoning (System 2)")
        reasoning_result = self.symbolic.reason(query)
        
        inference_time = time.time() - start_time
        
        result = {
            "text": text,
            "query": query,
            "premises": premises,
            "entities": entities,
            "reasoning": reasoning_result,
            "metrics": {
                "num_premises": len(premises),
                "inference_time": inference_time,
                "success": reasoning_result["success"]
            }
        }
        
        logger.success(f"Query processed in {inference_time:.2f}s - Answer: {reasoning_result['answer']}")
        return result
    
    def batch_evaluate(self, test_cases: List[Dict]) -> Dict[str, Any]:
        """
        Evaluate system on multiple test cases
        
        Args:
            test_cases: List of test cases with queries and expected answers
            
        Returns:
            Evaluation metrics
        """
        logger.info(f"Evaluating on {len(test_cases)} test cases")
        
        results = []
        correct = 0
        total_time = 0
        
        for idx, test_case in enumerate(test_cases):
            logger.info(f"Test case {idx+1}/{len(test_cases)}")
            
            if test_case["type"] == "visual":
                result = self.process_visual_query(
                    test_case["image"],
                    test_case["query"],
                    visualize=False
                )
            else:
                result = self.process_text_query(
                    test_case["text"],
                    test_case["query"]
                )
            
            # Check correctness
            expected = test_case.get("expected_answer", "").upper()
            actual = result["reasoning"]["answer"]
            
            is_correct = (expected == actual)
            if is_correct:
                correct += 1
            
            total_time += result["metrics"]["inference_time"]
            
            results.append({
                "test_case": test_case,
                "result": result,
                "correct": is_correct
            })
        
        # Calculate metrics
        accuracy = correct / len(test_cases) if test_cases else 0
        avg_time = total_time / len(test_cases) if test_cases else 0
        
        evaluation = {
            "total_cases": len(test_cases),
            "correct": correct,
            "accuracy": accuracy,
            "average_time": avg_time,
            "results": results
        }
        
        logger.success(f"Evaluation complete - Accuracy: {accuracy:.2%}")
        return evaluation
    
    def save_result(self, result: Dict[str, Any], filename: str):
        """Save reasoning result to file"""
        output_path = config.OUTPUTS_DIR / filename
        with open(output_path, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        logger.info(f"Result saved to {output_path}")
    
    def generate_report(self, result: Dict[str, Any]) -> str:
        """
        Generate human-readable report of reasoning process
        """
        report = []
        report.append("=" * 70)
        report.append("NEURO-SYMBOLIC REASONING REPORT")
        report.append("=" * 70)
        report.append("")
        
        # Query information
        report.append(f"Query: {result['query']}")
        report.append("")
        
        # Neural perception results
        if "detected_objects" in result:
            report.append("NEURAL PERCEPTION (System 1):")
            report.append("-" * 70)
            for obj in result["detected_objects"]:
                report.append(f"  {obj['id']}: {obj['color']} {obj['shape']} ({obj['size']})")
                report.append(f"    Confidence: {obj['confidence']:.2%}")
            report.append("")
        
        # Symbolic reasoning
        report.append("SYMBOLIC REASONING (System 2):")
        report.append("-" * 70)
        report.append(f"Answer: {result['reasoning']['answer']}")
        report.append("")
        
        if result['reasoning'].get('explanation'):
            report.append("Reasoning Trace:")
            report.append(result['reasoning']['explanation'])
            report.append("")
        
        # Knowledge base
        if result['reasoning'].get('knowledge_base'):
            report.append("Knowledge Base:")
            report.append(result['reasoning']['knowledge_base'])
            report.append("")
        
        # Metrics
        report.append("METRICS:")
        report.append("-" * 70)
        for key, value in result['metrics'].items():
            report.append(f"  {key}: {value}")
        
        report.append("=" * 70)
        
        return "\n".join(report)


def create_example_scenarios():
    """
    Create example test scenarios
    """
    scenarios = [
        {
            "name": "Visual Comparison",
            "type": "visual",
            "description": "Compare sizes of objects in image",
            "query": "Are all red circles larger than blue squares?",
            "expected_answer": "TRUE"
        },
        {
            "name": "Text Syllogism",
            "type": "text",
            "text": "All mammals are animals. All dogs are mammals.",
            "query": "Is dog an animal?",
            "expected_answer": "TRUE"
        },
        {
            "name": "Object Existence",
            "type": "visual",
            "query": "Is there a green triangle?",
            "expected_answer": "FALSE"
        },
        {
            "name": "Transitive Reasoning",
            "type": "text",
            "text": "Alice is taller than Bob. Bob is taller than Charlie.",
            "query": "Is Alice taller than Charlie?",
            "expected_answer": "TRUE"
        }
    ]
    
    return scenarios


if __name__ == "__main__":
    # Initialize system
    system = NeuroSymbolicSystem(device=config.NEURAL_CONFIG["device"])
    
    # Example usage
    logger.info("System ready for inference!")
    
    # Create example scenarios
    scenarios = create_example_scenarios()
    logger.info(f"Created {len(scenarios)} example scenarios")
