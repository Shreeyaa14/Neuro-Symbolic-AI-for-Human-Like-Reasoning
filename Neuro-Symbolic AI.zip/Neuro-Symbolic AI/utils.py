"""
Utility Functions
Helper functions for the Neuro-Symbolic Reasoning System
"""

import json
import pickle
from pathlib import Path
from typing import Any, Dict, List
import matplotlib.pyplot as plt
import numpy as np
from loguru import logger


def save_json(data: Dict[str, Any], filepath: Path):
    """Save data to JSON file"""
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2, default=str)
    logger.debug(f"Saved JSON to {filepath}")


def load_json(filepath: Path) -> Dict[str, Any]:
    """Load data from JSON file"""
    with open(filepath, 'r') as f:
        data = json.load(f)
    logger.debug(f"Loaded JSON from {filepath}")
    return data


def save_pickle(obj: Any, filepath: Path):
    """Save object using pickle"""
    with open(filepath, 'wb') as f:
        pickle.dump(obj, f)
    logger.debug(f"Saved pickle to {filepath}")


def load_pickle(filepath: Path) -> Any:
    """Load object from pickle"""
    with open(filepath, 'rb') as f:
        obj = pickle.load(f)
    logger.debug(f"Loaded pickle from {filepath}")
    return obj


def format_time(seconds: float) -> str:
    """Format time in human-readable format"""
    if seconds < 0.001:
        return f"{seconds*1000000:.0f}μs"
    elif seconds < 1:
        return f"{seconds*1000:.1f}ms"
    elif seconds < 60:
        return f"{seconds:.2f}s"
    else:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.1f}s"


def calculate_metrics(predictions: List[str], ground_truth: List[str]) -> Dict[str, float]:
    """
    Calculate classification metrics
    """
    correct = sum(p == g for p, g in zip(predictions, ground_truth))
    total = len(predictions)
    
    accuracy = correct / total if total > 0 else 0
    
    # For binary classification
    true_positives = sum((p == "TRUE" and g == "TRUE") 
                        for p, g in zip(predictions, ground_truth))
    false_positives = sum((p == "TRUE" and g == "FALSE") 
                         for p, g in zip(predictions, ground_truth))
    false_negatives = sum((p == "FALSE" and g == "TRUE") 
                         for p, g in zip(predictions, ground_truth))
    
    precision = (true_positives / (true_positives + false_positives) 
                if (true_positives + false_positives) > 0 else 0)
    recall = (true_positives / (true_positives + false_negatives) 
             if (true_positives + false_negatives) > 0 else 0)
    f1 = (2 * precision * recall / (precision + recall) 
         if (precision + recall) > 0 else 0)
    
    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
        "total": total,
        "correct": correct
    }


def plot_confusion_matrix(predictions: List[str], ground_truth: List[str], 
                         output_path: Path):
    """
    Plot confusion matrix
    """
    from sklearn.metrics import confusion_matrix
    import seaborn as sns
    
    labels = sorted(set(predictions + ground_truth))
    cm = confusion_matrix(ground_truth, predictions, labels=labels)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=labels, yticklabels=labels)
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.title('Confusion Matrix')
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    logger.info(f"Confusion matrix saved to {output_path}")


def create_performance_plot(metrics_history: List[Dict[str, float]], 
                          output_path: Path):
    """
    Create performance plot over time
    """
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    epochs = range(1, len(metrics_history) + 1)
    
    # Accuracy
    axes[0, 0].plot(epochs, [m['accuracy'] for m in metrics_history], 
                   marker='o', linewidth=2)
    axes[0, 0].set_title('Accuracy Over Time')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Accuracy')
    axes[0, 0].grid(True, alpha=0.3)
    
    # Precision and Recall
    axes[0, 1].plot(epochs, [m['precision'] for m in metrics_history], 
                   marker='o', label='Precision', linewidth=2)
    axes[0, 1].plot(epochs, [m['recall'] for m in metrics_history], 
                   marker='s', label='Recall', linewidth=2)
    axes[0, 1].set_title('Precision and Recall')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Score')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # F1 Score
    axes[1, 0].plot(epochs, [m['f1_score'] for m in metrics_history], 
                   marker='d', color='green', linewidth=2)
    axes[1, 0].set_title('F1 Score')
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('F1 Score')
    axes[1, 0].grid(True, alpha=0.3)
    
    # Inference Time (if available)
    if 'inference_time' in metrics_history[0]:
        axes[1, 1].plot(epochs, [m['inference_time'] for m in metrics_history], 
                       marker='x', color='red', linewidth=2)
        axes[1, 1].set_title('Inference Time')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Time (s)')
        axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    logger.info(f"Performance plot saved to {output_path}")


def print_table(headers: List[str], rows: List[List[Any]], 
               title: str = None):
    """
    Print formatted table
    """
    if title:
        print(f"\n{title}")
        print("=" * len(title))
    
    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))
    
    # Print header
    header_row = " | ".join(h.ljust(w) for h, w in zip(headers, col_widths))
    print(header_row)
    print("-" * len(header_row))
    
    # Print rows
    for row in rows:
        row_str = " | ".join(str(cell).ljust(w) 
                            for cell, w in zip(row, col_widths))
        print(row_str)
    print()


def analyze_errors(results: List[Dict]) -> Dict[str, Any]:
    """
    Analyze error patterns in results
    """
    errors = [r for r in results if not r.get('correct', True)]
    
    error_analysis = {
        "total_errors": len(errors),
        "error_rate": len(errors) / len(results) if results else 0,
        "error_types": {},
        "common_patterns": []
    }
    
    # Categorize errors
    for error in errors:
        error_type = error.get('type', 'unknown')
        if error_type not in error_analysis["error_types"]:
            error_analysis["error_types"][error_type] = []
        error_analysis["error_types"][error_type].append(error)
    
    return error_analysis


def create_summary_report(visual_metrics: Dict, text_metrics: Dict, 
                         output_path: Path):
    """
    Create executive summary report
    """
    report = []
    report.append("# EXECUTIVE SUMMARY")
    report.append("")
    report.append("## Overall Performance")
    report.append("")
    
    overall_acc = (
        (visual_metrics['correct'] + text_metrics['correct']) /
        (visual_metrics['total'] + text_metrics['total'])
    )
    
    report.append(f"- **Combined Accuracy**: {overall_acc:.1%}")
    report.append(f"- **Total Test Cases**: {visual_metrics['total'] + text_metrics['total']}")
    report.append(f"- **Visual Accuracy**: {visual_metrics['accuracy']:.1%}")
    report.append(f"- **Text Accuracy**: {text_metrics['accuracy']:.1%}")
    report.append("")
    
    report.append("## Key Findings")
    report.append("")
    report.append("### Strengths")
    report.append("- ✅ High accuracy on standard reasoning tasks")
    report.append("- ✅ Fully explainable decision-making process")
    report.append("- ✅ Fast inference times")
    report.append("")
    
    report.append("### Areas for Improvement")
    report.append("- 🔄 Complex multi-step reasoning")
    report.append("- 🔄 Handling ambiguous queries")
    report.append("- 🔄 Domain-specific knowledge integration")
    report.append("")
    
    report.append("## Recommendations")
    report.append("")
    report.append("1. Expand training data diversity")
    report.append("2. Enhance rule base with domain knowledge")
    report.append("3. Improve uncertainty quantification")
    report.append("4. Optimize inference engine performance")
    
    with open(output_path, 'w') as f:
        f.write("\n".join(report))
    
    logger.info(f"Summary report saved to {output_path}")


def validate_environment():
    """
    Validate that the environment is set up correctly
    """
    import torch
    
    checks = {
        "Python Version": True,
        "PyTorch Available": True,
        "CUDA Available": torch.cuda.is_available(),
        "NumPy Available": True,
        "Matplotlib Available": True,
    }
    
    print("\n" + "="*50)
    print("ENVIRONMENT VALIDATION")
    print("="*50 + "\n")
    
    for check, status in checks.items():
        status_str = "✅ PASS" if status else "⚠️  WARN"
        print(f"{check}: {status_str}")
    
    if torch.cuda.is_available():
        print(f"\nGPU: {torch.cuda.get_device_name(0)}")
    else:
        print("\nNote: Running on CPU (slower but functional)")
    
    print("\n" + "="*50 + "\n")


def benchmark_performance(system, num_iterations: int = 10) -> Dict[str, float]:
    """
    Benchmark system performance
    """
    import time
    from dataset_generator import VisualDatasetGenerator
    
    gen = VisualDatasetGenerator()
    times = []
    
    logger.info(f"Running benchmark with {num_iterations} iterations...")
    
    for i in range(num_iterations):
        # Generate test image
        image, _ = gen.generate_image(num_objects=3)
        temp_path = Path(f"/tmp/bench_{i}.png")
        image.save(temp_path)
        
        # Measure time
        start = time.time()
        result = system.process_visual_query(
            str(temp_path),
            "Is there a red circle?",
            visualize=False
        )
        elapsed = time.time() - start
        times.append(elapsed)
        
        # Cleanup
        temp_path.unlink()
    
    return {
        "mean": np.mean(times),
        "std": np.std(times),
        "min": np.min(times),
        "max": np.max(times),
        "median": np.median(times)
    }


if __name__ == "__main__":
    # Test utilities
    validate_environment()
