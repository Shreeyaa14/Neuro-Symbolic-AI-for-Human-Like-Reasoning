"""
Neural Perception Module (System 1)
Implements fast, intuitive perceptual processing using deep learning
"""

import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision import models
from PIL import Image
import numpy as np
from typing import Dict, List, Tuple, Optional
import cv2
from loguru import logger

class ObjectDetector(nn.Module):
    """
    Advanced object detection and attribute extraction
    """
    def __init__(self, model_name: str = "resnet50", num_classes: int = 50):
        super().__init__()
        self.model_name = model_name
        
        # Load pretrained backbone
        if model_name == "resnet50":
            try:
                backbone = models.resnet50(weights=None)
            except TypeError:
                backbone = models.resnet50(pretrained=False)
            self.feature_dim = backbone.fc.in_features
            backbone.fc = nn.Identity()
            self.backbone = backbone
        elif model_name == "efficientnet":
            try:
                backbone = models.efficientnet_b0(weights=None)
            except TypeError:
                backbone = models.efficientnet_b0(pretrained=False)
            self.feature_dim = backbone.classifier[-1].in_features
            backbone.classifier[-1] = nn.Identity()
            self.backbone = backbone
        else:
            raise ValueError(f"Unknown model: {model_name}")
        
        # Detection heads
        self.shape_classifier = nn.Linear(self.feature_dim, 6)  # 6 shapes
        self.color_classifier = nn.Linear(self.feature_dim, 8)  # 8 colors
        self.size_classifier = nn.Linear(self.feature_dim, 5)   # 5 sizes
        self.material_classifier = nn.Linear(self.feature_dim, 5)  # 5 materials
        
        # Bounding box regression
        self.bbox_regressor = nn.Linear(self.feature_dim, 4)
        
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Forward pass through the network"""
        # Extract features
        features = self.backbone(x)
        if len(features.shape) > 2:
            features = torch.flatten(features, 1)
        
        # Predict attributes
        return {
            "shape": self.shape_classifier(features),
            "color": self.color_classifier(features),
            "size": self.size_classifier(features),
            "material": self.material_classifier(features),
            "bbox": self.bbox_regressor(features),
            "features": features,
        }


class NeuralPerceptionModule:
    """
    Complete neural perception system for visual understanding
    """
    def __init__(self, model_name: str = "resnet50", device: str = "cpu"):
        self.device = device
        self.model = ObjectDetector(model_name).to(device)
        self.model.eval()
        
        # Image preprocessing
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])
        
        # Attribute mappings
        self.shape_map = ["circle", "square", "triangle", "rectangle", "pentagon", "hexagon"]
        self.color_map = ["red", "blue", "green", "yellow", "purple", "orange", "cyan", "magenta"]
        self.size_map = ["tiny", "small", "medium", "large", "huge"]
        self.material_map = ["metal", "rubber", "wood", "plastic", "glass"]
        
        logger.info(f"Neural Perception Module initialized on {device}")
    
    def detect_objects(self, image_path: str) -> List[Dict]:
        """
        Detect objects and extract their attributes from an image
        
        Args:
            image_path: Path to input image
            
        Returns:
            List of detected objects with attributes
        """
        # Load and preprocess image
        image = Image.open(image_path).convert("RGB")
        image_np = np.array(image)

        hsv_full = cv2.cvtColor(image_np, cv2.COLOR_RGB2HSV)
        sat_full = hsv_full[:, :, 1]
        sat_mask_full = (sat_full > 30).astype(np.uint8)
        
        # Segment objects (prefer color-aware segmentation for real photos)
        objects = self._segment_objects_color_aware(image_np)
        if not objects:
            objects = self._segment_objects(image_np)
        
        detected_objects = []
        image_area = float(image_np.shape[0] * image_np.shape[1])
        for idx, obj_region in enumerate(objects):
            x, y, w, h = obj_region["bbox"]
            contour = obj_region["contour"]
            area = float(obj_region.get("area", 0.0))

            # Filter contours that are likely background/table edges
            if image_area > 0 and area / image_area > 0.80:
                continue

            mask = np.zeros(image_np.shape[:2], dtype=np.uint8)
            cv2.drawContours(mask, [contour], -1, 1, -1)
            total_px = int(mask.sum())
            if total_px <= 0:
                continue
            sat_px = int((sat_mask_full * mask).sum())
            sat_ratio = sat_px / float(total_px)
            if sat_ratio < 0.10:
                continue

            shape = self._classify_shape(contour)
            color = self._extract_color_from_contour(image_np, contour)

            measure = None
            try:
                hull = cv2.convexHull(contour)
                if shape == "circle":
                    (cx, cy), r = cv2.minEnclosingCircle(hull)
                    measure = float(2.0 * r)
                else:
                    rect = cv2.minAreaRect(hull)
                    (rw, rh) = rect[1]
                    if rw and rh:
                        measure = float(max(rw, rh))
            except Exception:
                measure = None

            detected_objects.append({
                "id": f"obj_{idx+1}",
                "shape": shape,
                "color": color,
                "size": "medium",
                "material": "plastic",
                "bbox": obj_region["bbox"],
                "area": area,
                "measure": measure,
                "confidence": 0.99,
                "position": {"x": x + w/2, "y": y + h/2}
            })

        # Deduplicate overlapping detections (keep larger area)
        if detected_objects:
            detected_objects = sorted(detected_objects, key=lambda o: float(o.get("area", 0.0)), reverse=True)
            kept = []
            for o in detected_objects:
                x1, y1, w1, h1 = o["bbox"]
                ax1, ay1, ax2, ay2 = x1, y1, x1 + w1, y1 + h1
                ok = True
                for k in kept:
                    x2, y2, w2, h2 = k["bbox"]
                    bx1, by1, bx2, by2 = x2, y2, x2 + w2, y2 + h2
                    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
                    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
                    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
                    inter = float(iw * ih)
                    union = float((w1 * h1) + (w2 * h2) - inter) if (w1 * h1 + w2 * h2) > 0 else 1.0
                    iou = inter / union
                    if iou > 0.60:
                        ok = False
                        break
                if ok:
                    kept.append(o)
            detected_objects = kept

        # Assign size categories based on relative object areas for consistent comparisons.
        if detected_objects:
            areas = [float(o.get("area", 0.0)) for o in detected_objects]
            max_area = max(areas) if areas else 0.0
            for o in detected_objects:
                a = float(o.get("area", 0.0))
                if max_area <= 0:
                    o["size"] = "medium"
                    continue
                r = a / max_area
                if r < 0.12:
                    o["size"] = "tiny"
                elif r < 0.30:
                    o["size"] = "small"
                elif r < 0.60:
                    o["size"] = "medium"
                elif r < 0.85:
                    o["size"] = "large"
                else:
                    o["size"] = "huge"
        
        logger.info(f"Detected {len(detected_objects)} objects")
        return detected_objects
    
    def _segment_objects(self, image: np.ndarray) -> List[Dict]:
        """
        Segment individual objects from image using computer vision
        """
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        s = hsv[:, :, 1]

        sat_mask = np.zeros_like(s, dtype=np.uint8)
        sat_mask[s > 30] = 255

        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)

        binary = cv2.bitwise_or(sat_mask, edges)

        kernel = np.ones((3, 3), np.uint8)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
        
        # Find contours
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        objects = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 100:  # Filter small noise
                x, y, w, h = cv2.boundingRect(contour)
                objects.append({
                    "bbox": (x, y, w, h),
                    "area": area,
                    "contour": contour
                })
        
        return objects

    def _segment_objects_color_aware(self, image: np.ndarray) -> List[Dict]:
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        h = hsv[:, :, 0]
        s = hsv[:, :, 1]
        v = hsv[:, :, 2]

        base = ((s > 45) & (v > 35)).astype(np.uint8) * 255

        def in_range(hh, lo, hi):
            return ((hh >= lo) & (hh <= hi))

        masks = []
        red = ((in_range(h, 0, 10) | in_range(h, 170, 179)) & (base > 0)).astype(np.uint8) * 255
        blue = (in_range(h, 100, 130) & (base > 0)).astype(np.uint8) * 255
        green = (in_range(h, 40, 85) & (base > 0)).astype(np.uint8) * 255
        yellow = (in_range(h, 20, 35) & (base > 0)).astype(np.uint8) * 255
        purple = (in_range(h, 130, 160) & (base > 0)).astype(np.uint8) * 255
        cyan = (in_range(h, 85, 100) & (base > 0)).astype(np.uint8) * 255
        orange = (in_range(h, 10, 20) & (base > 0)).astype(np.uint8) * 255

        for m in [red, blue, green, yellow, purple, cyan, orange]:
            if int(m.sum()) > 0:
                masks.append(m)

        if not masks:
            return []

        combined = np.zeros(image.shape[:2], dtype=np.uint8)
        for m in masks:
            combined = cv2.bitwise_or(combined, m)

        kernel = np.ones((5, 5), np.uint8)
        combined = cv2.morphologyEx(combined, cv2.MORPH_OPEN, kernel, iterations=1)
        combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel, iterations=2)

        contours, _ = cv2.findContours(combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        objects = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 150:
                x, y, w, h2 = cv2.boundingRect(contour)
                objects.append({
                    "bbox": (x, y, w, h2),
                    "area": area,
                    "contour": contour,
                })
        return objects

    def _classify_shape(self, contour: np.ndarray) -> str:
        """Classify shape using contour approximation."""
        hull = cv2.convexHull(contour)
        peri = cv2.arcLength(hull, True)
        if peri <= 0:
            return "circle"

        approx = cv2.approxPolyDP(hull, 0.04 * peri, True)
        vertices = len(approx)

        area = cv2.contourArea(hull)
        circularity = (4.0 * np.pi * area) / (peri * peri) if peri else 0.0

        if vertices == 3:
            return "triangle"
        if vertices == 4:
            x, y, w, h = cv2.boundingRect(approx)
            ar = float(w) / float(h) if h else 1.0
            rect = cv2.minAreaRect(hull)
            (rw, rh) = rect[1]
            if rw and rh:
                rar = float(max(rw, rh)) / float(min(rw, rh))
            else:
                rar = ar
            return "square" if 0.80 <= rar <= 1.25 else "rectangle"
        if vertices in {5, 6}:
            x, y, w, h = cv2.boundingRect(hull)
            ar = float(w) / float(h) if h else 1.0
            rect_area = float(w * h) if w and h else 1.0
            extent = float(area) / rect_area if rect_area else 0.0
            # Many real photos (e.g., cubes/perspective) create 5-6 vertex hulls.
            # If the object is compact/box-like, treat as square/rectangle.
            if extent >= 0.86:
                return "square" if 0.80 <= ar <= 1.25 else "rectangle"
            if circularity >= 0.84:
                return "circle"
            if extent >= 0.55:
                return "square" if 0.75 <= ar <= 1.35 else "rectangle"
            if extent >= 0.75:
                return "square" if 0.9 <= ar <= 1.1 else "rectangle"
            return "pentagon" if vertices == 5 else "hexagon"

        x, y, w, h = cv2.boundingRect(hull)
        ar = float(w) / float(h) if h else 1.0
        rect_area = float(w * h) if w and h else 1.0
        extent = float(area) / rect_area if rect_area else 0.0
        rect = cv2.minAreaRect(hull)
        (rw, rh) = rect[1]
        rar = float(max(rw, rh)) / float(min(rw, rh)) if (rw and rh) else ar
        # Extent is a strong cue: squares/rectangles fill their bbox more than circles.
        if extent >= 0.86:
            return "square" if 0.80 <= rar <= 1.25 else "rectangle"
        if circularity >= 0.84:
            return "circle"
        if extent >= 0.60:
            return "square" if 0.80 <= rar <= 1.25 else "rectangle"
        return "circle" if circularity >= 0.78 else "rectangle"

    def _extract_color_from_contour(self, image_rgb: np.ndarray, contour: np.ndarray) -> str:
        """Estimate dominant color inside contour using HSV pixels and circular mean hue."""
        mask = np.zeros(image_rgb.shape[:2], dtype=np.uint8)
        cv2.drawContours(mask, [contour], -1, 255, -1)

        hsv = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2HSV)
        hsv_px = hsv[mask == 255]
        if hsv_px.size == 0:
            return "blue"

        hsv_px = hsv_px.reshape(-1, 3).astype(np.float32)
        h = hsv_px[:, 0]
        s = hsv_px[:, 1]
        v = hsv_px[:, 2]

        keep = (s > 50) & (v > 40)
        if keep.sum() < 50:
            keep = (s > 25) & (v > 30)

        hh = h[keep]
        if hh.size == 0:
            hh = h

        angles = (hh / 180.0) * (2.0 * np.pi)
        mean_sin = float(np.sin(angles).mean())
        mean_cos = float(np.cos(angles).mean())
        mean_angle = float(np.arctan2(mean_sin, mean_cos))
        if mean_angle < 0:
            mean_angle += 2.0 * np.pi

        mean_h = (mean_angle / (2.0 * np.pi)) * 180.0

        if mean_h < 10 or mean_h >= 170:
            return "red"
        if mean_h < 25:
            return "orange"
        if mean_h < 35:
            return "yellow"
        if mean_h < 85:
            return "green"
        if mean_h < 100:
            return "cyan"
        if mean_h < 130:
            return "blue"
        if mean_h < 155:
            return "purple"
        return "magenta"

    def _classify_size(self, obj_area: float, image_area: float) -> str:
        """Classify object size based on contour area ratio."""
        if image_area <= 0:
            return "medium"
        ratio = obj_area / image_area
        if ratio < 0.008:
            return "tiny"
        if ratio < 0.02:
            return "small"
        if ratio < 0.05:
            return "medium"
        if ratio < 0.10:
            return "large"
        return "huge"
    
    def _predict_attributes(self, image_patch: Image.Image) -> Dict:
        """
        Predict object attributes using neural network
        """
        # Preprocess
        img_tensor = self.transform(image_patch).unsqueeze(0).to(self.device)
        
        # Inference
        with torch.no_grad():
            outputs = self.model(img_tensor)
        
        # Get predictions
        shape_pred = torch.argmax(outputs["shape"], dim=1).item()
        color_pred = torch.argmax(outputs["color"], dim=1).item()
        size_pred = torch.argmax(outputs["size"], dim=1).item()
        material_pred = torch.argmax(outputs["material"], dim=1).item()
        
        # Also use classical CV for color verification
        cv_color = self._extract_dominant_color(image_patch)
        
        # Calculate confidence
        shape_conf = torch.softmax(outputs["shape"], dim=1).max().item()
        color_conf = torch.softmax(outputs["color"], dim=1).max().item()
        
        return {
            "shape": self.shape_map[shape_pred],
            "color": cv_color if cv_color else self.color_map[color_pred],
            "size": self.size_map[size_pred],
            "material": self.material_map[material_pred],
            "confidence": (shape_conf + color_conf) / 2
        }
    
    def _extract_dominant_color(self, image: Image.Image) -> Optional[str]:
        """
        Extract dominant color using K-means clustering
        """
        img_array = np.array(image.resize((50, 50)))
        pixels = img_array.reshape(-1, 3)
        
        # Simple color matching based on HSV
        hsv = cv2.cvtColor(img_array, cv2.COLOR_RGB2HSV)
        mean_hue = np.mean(hsv[:, :, 0])
        
        # Map hue to color name
        if mean_hue < 15 or mean_hue > 165:
            return "red"
        elif mean_hue < 35:
            return "orange"
        elif mean_hue < 75:
            return "yellow"
        elif mean_hue < 90:
            return "green"
        elif mean_hue < 130:
            return "cyan"
        elif mean_hue < 155:
            return "blue"
        else:
            return "purple"
    
    def visualize_detection(self, image_path: str, objects: List[Dict], output_path: str):
        """
        Visualize detected objects with bounding boxes and labels
        """
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        for obj in objects:
            x, y, w, h = obj["bbox"]
            color = (0, 255, 0)
            
            # Draw bounding box
            cv2.rectangle(image, (x, y), (x+w, y+h), color, 2)
            
            # Draw label
            label = f"{obj['color']} {obj['shape']}"
            cv2.putText(image, label, (x, y-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Save
        output_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_path, output_image)
        logger.info(f"Visualization saved to {output_path}")


class TextPerceptionModule:
    """
    Text understanding for logical reasoning tasks
    """
    def __init__(self, model_name: str = "bert-base-uncased"):
        self.tokenizer = None
        self.model = None
        try:
            from transformers import AutoTokenizer, AutoModel
            
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            self.model = AutoModel.from_pretrained(model_name)
            self.model.eval()
            
            logger.info(f"Text Perception Module initialized with {model_name}")
        except Exception as e:
            logger.warning(f"Text Perception Module running without transformers model: {e}")
    
    def parse_premises(self, text: str) -> List[str]:
        """
        Parse text into individual logical premises
        """
        try:
            import nltk
            try:
                nltk.data.find('tokenizers/punkt')
                sentences = nltk.sent_tokenize(text)
                return [s.strip() for s in sentences if s.strip()]
            except Exception:
                pass
        except Exception:
            pass

        # Fallback: basic splitting without external downloads
        raw = text.replace("\n", ". ")
        parts = [p.strip() for p in raw.split(".")]
        return [p for p in parts if p]
    
    def extract_entities(self, text: str) -> Dict:
        """
        Extract entities and relationships from text
        """
        entities = []
        relations = []

        def norm_noun(w: str) -> str:
            w = (w or "").strip().lower()
            # Avoid damaging common proper nouns / endings (e.g., paris -> pari)
            if w.endswith("ss") or w.endswith("is") or w.endswith("us"):
                return w
            if len(w) > 3 and w.endswith("s"):
                return w[:-1]
            return w

        import re
        patterns = [
            (r"all (\w+) are (\w+)", lambda m: ("is_a", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"all (\w+) can (\w+)", lambda m: ("all_can", norm_noun(m.group(1)), m.group(2).lower())),
            (r"every (\w+) are (\w+)", lambda m: ("is_a", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"(\w+) is an? (\w+)", lambda m: ("is_a", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"no (\w+) can (\w+)", lambda m: ("cannot", norm_noun(m.group(1)), m.group(2).lower())),
            (r"(\w+) is (\w+) than (\w+)", lambda m: (f"{m.group(2).lower()}_than", norm_noun(m.group(1)), norm_noun(m.group(3)))),
            (r"(\w+) is (?:in|at) (\w+)", lambda m: ("at", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"(\w+) was (?:in|at) (\w+)", lambda m: ("at", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"(\w+) has (\w+)", lambda m: ("has", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"(\w+) likes (\w+)", lambda m: ("likes", norm_noun(m.group(1)), norm_noun(m.group(2)))),
            (r"(\w+) (?:happened|occurred) in (\w+)", lambda m: ("at_time", norm_noun(m.group(1)), norm_noun(m.group(2)))),
        ]

        for pattern, builder in patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                pred, subj, obj = builder(match)
                if subj and obj:
                    entities.extend([subj, obj])
                    relations.append({
                        "subject": subj,
                        "predicate": pred,
                        "object": obj
                    })

        return {
            "entities": sorted(set(entities)),
            "relations": relations
        }
